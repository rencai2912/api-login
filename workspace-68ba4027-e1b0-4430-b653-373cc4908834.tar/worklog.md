---
Task ID: 1
Agent: Z.ai Code (主 Agent)
Task: 构建「云鉴 CloudAuth」——基于 Cloudflare Workers + D1 的账户系统演示站点（简体中文），含登录/注册、每个 IP 最多注册 3 个账户的限制、完整 REST API、中文 API 文档、Cloudflare D1 数据库配置部署教程。

Work Log:
- 探索项目现状：Next.js 16 + shadcn/ui + Prisma(SQLite) 脚手架，dev server 已在 3000 端口运行
- 设计并推送 Prisma schema（prisma/schema.prisma）：User / Session / IpRegistration 三表，IpRegistration 带 ip 索引，外键级联删除；执行 bun run db:push
- 实现后端工具库：
  - src/lib/api.ts：统一成功/失败 JSON 响应封装（success/data/error.code/error.message）
  - src/lib/auth.ts：scrypt 密码加盐哈希、客户端 IP 解析（x-forwarded-for 链）、IP 脱敏、会话创建/校验/惰性过期清理、内存限流器（注册 10 次/10 分钟、登录 10 次/5 分钟）
- 实现 8 个 REST API 路由 + 1 个演示专用接口：
  - POST /api/auth/register（核心：countIpRegistrations(ip) >= 3 时返回 429 IP_LIMIT_EXCEEDED；注册成功即签发会话 Cookie）
  - POST /api/auth/login（用户名或邮箱 + 密码；401 INVALID_CREDENTIALS）
  - POST /api/auth/logout、GET /api/auth/me、GET /api/ip-usage（公开）
  - PATCH /api/account/profile（昵称）、GET/DELETE /api/account/sessions（会话列表/注销，禁止注销当前会话）
  - DELETE /api/demo/reset（仅演示环境使用，教程中的 Worker 版不含）
- 前端（全部在唯一用户可见路由 / 下，三个标签页）：
  - src/components/account/site-shell.tsx：吸顶页头 + 三个 Tab 导航 + 深浅主题切换（next-themes）+ mt-auto 粘性页脚
  - src/components/account/home-tab.tsx：Hero（四大特性）+ 登录/注册卡片（注册表单实时展示 IP 配额 X/3、达上限禁用按钮）+ 控制台仪表盘（账户信息/昵称行内编辑/IP 配额进度条/会话管理表格）+ 演示重置 AlertDialog
  - src/components/account/api-docs-tab.tsx：完整中文 API 文档（8 个接口：方法徽章/参数表/curl 请求示例/JSON 响应示例/错误码表 + 全局错误码汇总 + fetch 前端调用示例），Accordion 折叠组织
  - src/components/account/tutorial-tab.tsx：Cloudflare D1 部署教程（8 步时间线：注册账号安装 Wrangler → 创建 D1 → wrangler.toml → schema.sql 建表 → 完整 worker.js → 本地 wrangler dev → wrangler deploy 上线 → D1 日常运维）+ 6 条 FAQ
  - src/components/account/cloudflare-assets.ts：可复制/可下载的完整生产代码：wrangler.toml、schema.sql（users/sessions/ip_registrations 三表）、worker.js（约 300 行零依赖单文件，D1 + Web Crypto PBKDF2-SHA256 十万次迭代 + CF-Connecting-IP 取真实 IP + 同一套 8 接口）
  - src/components/code-block.tsx：代码块组件（终端风格标题栏、复制按钮、文件下载按钮、react-syntax-highlighter 动态加载 + SSR 降级为纯文本）
- 主题定制：globals.css 主色改为 Cloudflare 橙（oklch(0.67 0.19 48) / 深色 oklch(0.72 0.17 50)）；layout.tsx 更新 zh-CN 与中文 metadata，接入 ThemeProvider
- 修复：api-docs-tab Accordion key 冲突（GET 与 DELETE /api/account/sessions 同路径）→ key/value 改用 `${method} ${path}`，React duplicate key 报错消除

Agent-browser 端到端验证（全部通过）：
- 首页渲染：Hero/登录注册/导航/页脚正常，无空白或水合错误
- 注册 cloud_tester → 自动登录进入控制台，Toast 提示正常
- 用 curl 模拟同 IP（X-Forwarded-For: ::1）注册第 2、3 个账户：used 2/3 → 3/3，remaining=0
- 第 4 次注册：前端注册按钮禁用 + 表单提示"已达注册上限"；服务端直接 POST 返回 429 IP_LIMIT_EXCEEDED
- 登录（正确凭证成功、错误密码显示"账号或密码错误"）、退出登录正常
- 多设备会话：curl 模拟第二设备登录 → 会话列表出现"其他设备"（IP 脱敏 203.0.**.**）→ 点"注销其他会话"后旧会话调用 /api/auth/me 返回 401
- 昵称行内编辑（保存后即时生效）、演示重置 AlertDialog 流程（配额回到 0/3，注册按钮恢复可用）
- API 文档 / 部署教程标签页渲染完整，Accordion 展开、代码块复制按钮正常
- VLM 分析 4 张截图（浅色/深色/移动端/文档页）：无文字溢出、无布局错乱、橙色主题符合要求
- 粘性页脚：长页面贴文档底（footerBottom==docHeight）、短内容模拟 footerBottom==viewportHeight（吸底成功）
- dev.log 无服务端错误；浏览器 console 无残留报错（key 冲突修复后清零）
- bun run lint 通过

Stage Summary:
- 交付物：单页站点（/ 路由）= 在线可用的账户系统演示 + 中文 API 文档 + Cloudflare D1 教程
- 核心特性「每 IP 最多 3 账户」全链路验证通过（前端禁用 + 后端 429 强制拒绝，双保险）
- 教程提供可直接复制/下载的三个生产文件（wrangler.toml / schema.sql / worker.js），照做即可部署到 Cloudflare（wrangler d1 create → d1 execute --file=schema.sql → wrangler deploy）
- 技术决策：演示站用 Next.js API 路由 + Prisma SQLite 复刻线上行为；生产版 Worker 用 D1 + PBKDF2（Web Crypto），不含演示重置接口；密码永不明文存储；会话 HttpOnly Cookie 7 天
- 演示便利性：提供"重置全部数据"演示专用功能（生产版不含），便于反复测试 IP 限制
