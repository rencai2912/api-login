// react-syntax-highlighter v15 未附带 TypeScript 类型声明，此处补充最小声明
declare module "react-syntax-highlighter" {
  import type { ComponentType } from "react";

  export interface SyntaxHighlighterProps {
    language?: string;
    style?: Record<string, unknown>;
    customStyle?: React.CSSProperties;
    showLineNumbers?: boolean;
    wrapLongLines?: boolean;
    className?: string;
    children: string;
    [key: string]: unknown;
  }

  export const Prism: ComponentType<SyntaxHighlighterProps>;
  export const PrismLight: ComponentType<SyntaxHighlighterProps>;
  export const PrismAsync: ComponentType<SyntaxHighlighterProps>;
}

declare module "react-syntax-highlighter/dist/esm/styles/prism" {
  export const oneDark: Record<string, unknown>;
  export const atomDark: Record<string, unknown>;
  export const vsDark: Record<string, unknown>;
}
