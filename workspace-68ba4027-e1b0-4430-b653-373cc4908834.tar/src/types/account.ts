/** 对外输出的用户信息 */
export interface PublicUser {
  id: string;
  username: string;
  email: string;
  nickname: string | null;
  registerIp: string; // 已脱敏
  createdAt: string;
}

/** IP 配额信息 */
export interface IpInfo {
  address: string;
  used: number;
  limit: number;
}

/** GET /api/auth/me 响应 */
export interface MeData {
  user: PublicUser;
  ip: IpInfo;
}

/** GET /api/ip-usage 响应 */
export interface IpUsageData {
  ip: string;
  used: number;
  limit: number;
  remaining: number;
}

/** 会话条目 */
export interface SessionInfo {
  id: string;
  ip: string;
  userAgent: string;
  createdAt: string;
  expiresAt: string;
  current: boolean;
}

/** 统一响应包装 */
export interface ApiEnvelope<T> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    [key: string]: unknown;
  };
}
