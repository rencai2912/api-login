import { SiteShell } from "@/components/account/site-shell";

export default function Home() {
  return <SiteShell />;
}
