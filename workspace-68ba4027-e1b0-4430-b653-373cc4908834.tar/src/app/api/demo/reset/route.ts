import { db } from "@/lib/db";
import { ok } from "@/lib/api";

export const dynamic = "force-dynamic";

/**
 * DELETE /api/demo/reset — 重置演示数据（仅限本演示环境使用！）
 * 生产环境请勿实现该接口；教程中的 Cloudflare Worker 版本也不包含此接口。
 */
export async function DELETE() {
  await db.session.deleteMany({});
  await db.ipRegistration.deleteMany({});
  await db.user.deleteMany({});
  return ok({
    message: "演示数据已全部重置（用户、会话、IP 注册记录均已清空）",
  });
}
