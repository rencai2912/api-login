import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail } from "@/lib/api";
import { getSession, publicUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

/**
 * PATCH /api/account/profile — 更新账户资料（需登录）
 * 目前支持修改昵称
 */
export async function PATCH(req: NextRequest) {
  const session = await getSession(req);
  if (!session) {
    return fail(401, "UNAUTHORIZED", "未登录或会话已过期");
  }

  const body = await req.json().catch(() => null);
  const nickname = String(body?.nickname ?? "").trim();

  if (nickname.length > 20) {
    return fail(400, "INVALID_INPUT", "昵称长度不能超过 20 个字符");
  }

  const user = await db.user.update({
    where: { id: session.userId },
    data: { nickname: nickname || null },
  });

  return ok({ user: publicUser(user) });
}
