import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail } from "@/lib/api";
import { SESSION_COOKIE, getSession, maskIp } from "@/lib/auth";

export const dynamic = "force-dynamic";

/**
 * GET /api/account/sessions — 获取当前用户的所有会话（需登录）
 */
export async function GET(req: NextRequest) {
  const session = await getSession(req);
  if (!session) {
    return fail(401, "UNAUTHORIZED", "未登录或会话已过期");
  }

  const currentToken = req.cookies.get(SESSION_COOKIE)?.value;
  const sessions = await db.session.findMany({
    where: { userId: session.userId },
    orderBy: { createdAt: "desc" },
  });

  return ok({
    sessions: sessions.map((s) => ({
      id: s.id,
      ip: maskIp(s.ip ?? "未知"),
      userAgent: s.userAgent ?? "",
      createdAt: s.createdAt,
      expiresAt: s.expiresAt,
      current: s.token === currentToken,
    })),
  });
}

/**
 * DELETE /api/account/sessions — 注销会话（需登录）
 * body: { sessionId?: string } 传入则注销指定会话，不传则注销除当前外的全部会话
 */
export async function DELETE(req: NextRequest) {
  const session = await getSession(req);
  if (!session) {
    return fail(401, "UNAUTHORIZED", "未登录或会话已过期");
  }

  const body = await req.json().catch(() => null);
  const currentToken = req.cookies.get(SESSION_COOKIE)?.value;
  const sessionId = body?.sessionId ? String(body.sessionId) : null;

  if (sessionId) {
    // 注销指定会话
    const target = await db.session.findUnique({ where: { id: sessionId } });
    if (!target || target.userId !== session.userId) {
      return fail(404, "NOT_FOUND", "会话不存在");
    }
    if (target.token === currentToken) {
      return fail(
        400,
        "INVALID_INPUT",
        "不能通过此接口注销当前会话，请使用「退出登录」"
      );
    }
    await db.session.delete({ where: { id: sessionId } });
    return ok({ revoked: 1 });
  }

  // 注销除当前会话外的全部会话
  const result = await db.session.deleteMany({
    where: { userId: session.userId, token: { not: currentToken ?? "" } },
  });
  return ok({ revoked: result.count });
}
