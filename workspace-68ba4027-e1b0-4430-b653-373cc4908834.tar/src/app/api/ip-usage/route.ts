import type { NextRequest } from "next/server";
import { ok } from "@/lib/api";
import {
  MAX_ACCOUNTS_PER_IP,
  getClientIp,
  countIpRegistrations,
} from "@/lib/auth";

export const dynamic = "force-dynamic";

/**
 * GET /api/ip-usage — 查询当前 IP 的注册配额（公开接口）
 * 用于注册表单展示「该 IP 已注册 X / 3 个账户」
 */
export async function GET(req: NextRequest) {
  const ip = getClientIp(req);
  const used = await countIpRegistrations(ip);
  return ok({
    ip,
    used,
    limit: MAX_ACCOUNTS_PER_IP,
    remaining: Math.max(0, MAX_ACCOUNTS_PER_IP - used),
  });
}
