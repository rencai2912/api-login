import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail } from "@/lib/api";
import {
  MAX_ACCOUNTS_PER_IP,
  SESSION_COOKIE,
  SESSION_TTL_MS,
  getClientIp,
  hashPassword,
  createSession,
  publicUser,
  rateLimit,
  countIpRegistrations,
} from "@/lib/auth";

export const dynamic = "force-dynamic";

const USERNAME_RE = /^[a-zA-Z][a-zA-Z0-9_]{2,19}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/**
 * POST /api/auth/register — 注册新账户
 * 限制：同一 IP 最多注册 MAX_ACCOUNTS_PER_IP(3) 个账户
 */
export async function POST(req: NextRequest) {
  const ip = getClientIp(req);

  // 注册频率限制：每个 IP 每 10 分钟最多 10 次尝试
  const rl = rateLimit(`register:${ip}`, 10, 10 * 60 * 1000);
  if (!rl.allowed) {
    return fail(
      429,
      "RATE_LIMITED",
      "注册请求过于频繁，请稍后再试",
      rl.retryAfterSec ? { retryAfterSec: rl.retryAfterSec } : undefined
    );
  }

  const body = await req.json().catch(() => null);
  if (!body || typeof body !== "object") {
    return fail(400, "INVALID_INPUT", "请求体必须是合法的 JSON");
  }

  const username = String(body.username ?? "").trim();
  const email = String(body.email ?? "")
    .trim()
    .toLowerCase();
  const password = String(body.password ?? "");
  const nickname = String(body.nickname ?? "").trim();

  // 字段校验
  if (!USERNAME_RE.test(username)) {
    return fail(
      400,
      "INVALID_INPUT",
      "用户名格式不正确：需以字母开头，3-20 位，仅支持字母、数字、下划线"
    );
  }
  if (!EMAIL_RE.test(email)) {
    return fail(400, "INVALID_INPUT", "邮箱格式不正确");
  }
  if (password.length < 8) {
    return fail(400, "INVALID_INPUT", "密码长度至少 8 位");
  }
  if (nickname.length > 20) {
    return fail(400, "INVALID_INPUT", "昵称长度不能超过 20 个字符");
  }

  // ★ 核心：同一 IP 注册数量限制
  const used = await countIpRegistrations(ip);
  if (used >= MAX_ACCOUNTS_PER_IP) {
    return fail(
      429,
      "IP_LIMIT_EXCEEDED",
      `该 IP 地址最多可注册 ${MAX_ACCOUNTS_PER_IP} 个账户，已达上限`,
      { ip, limit: MAX_ACCOUNTS_PER_IP, used }
    );
  }

  // 用户名 / 邮箱唯一性
  const [usernameTaken, emailTaken] = await Promise.all([
    db.user.findUnique({ where: { username } }),
    db.user.findUnique({ where: { email } }),
  ]);
  if (usernameTaken) {
    return fail(409, "USERNAME_EXISTS", "用户名已被注册");
  }
  if (emailTaken) {
    return fail(409, "EMAIL_EXISTS", "邮箱已被注册");
  }

  // 创建用户 + IP 注册记录 + 会话（注册即登录）
  const user = await db.user.create({
    data: {
      username,
      email,
      passwordHash: hashPassword(password),
      nickname: nickname || null,
      registerIp: ip,
    },
  });
  await db.ipRegistration.create({ data: { ip, userId: user.id } });
  const { token } = await createSession(
    user.id,
    ip,
    req.headers.get("user-agent") ?? ""
  );

  const res = ok({
    user: publicUser(user),
    ip: { address: ip, used: used + 1, limit: MAX_ACCOUNTS_PER_IP },
  });
  res.cookies.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_TTL_MS / 1000,
  });
  return res;
}
