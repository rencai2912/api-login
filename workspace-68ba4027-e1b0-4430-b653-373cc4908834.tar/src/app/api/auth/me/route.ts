import type { NextRequest } from "next/server";
import { ok, fail } from "@/lib/api";
import {
  MAX_ACCOUNTS_PER_IP,
  getSession,
  publicUser,
  getClientIp,
  countIpRegistrations,
} from "@/lib/auth";

export const dynamic = "force-dynamic";

/**
 * GET /api/auth/me — 获取当前登录用户信息（需登录）
 */
export async function GET(req: NextRequest) {
  const session = await getSession(req);
  if (!session) {
    return fail(401, "UNAUTHORIZED", "未登录或会话已过期");
  }
  const ip = getClientIp(req);
  const used = await countIpRegistrations(ip);
  return ok({
    user: publicUser(session.user),
    ip: { address: ip, used, limit: MAX_ACCOUNTS_PER_IP },
  });
}
