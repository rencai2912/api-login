import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail } from "@/lib/api";
import {
  SESSION_COOKIE,
  SESSION_TTL_MS,
  getClientIp,
  verifyPassword,
  createSession,
  publicUser,
  rateLimit,
  cleanExpiredSessions,
} from "@/lib/auth";

export const dynamic = "force-dynamic";

/**
 * POST /api/auth/login — 登录
 * 支持用户名或邮箱 + 密码；带防暴力限流
 */
export async function POST(req: NextRequest) {
  const ip = getClientIp(req);

  // 登录频率限制：每个 IP 每 5 分钟最多 10 次尝试
  const rl = rateLimit(`login:${ip}`, 10, 5 * 60 * 1000);
  if (!rl.allowed) {
    return fail(
      429,
      "RATE_LIMITED",
      "登录尝试过于频繁，请稍后再试",
      rl.retryAfterSec ? { retryAfterSec: rl.retryAfterSec } : undefined
    );
  }

  const body = await req.json().catch(() => null);
  const identifier = String(body?.identifier ?? "").trim();
  const password = String(body?.password ?? "");

  if (!identifier || !password) {
    return fail(400, "INVALID_INPUT", "请输入账号和密码");
  }

  // 支持用户名或邮箱登录
  const user = identifier.includes("@")
    ? await db.user.findUnique({ where: { email: identifier.toLowerCase() } })
    : await db.user.findUnique({ where: { username: identifier } });

  if (!user || !verifyPassword(password, user.passwordHash)) {
    return fail(401, "INVALID_CREDENTIALS", "账号或密码错误");
  }

  // 惰性清理过期会话
  cleanExpiredSessions().catch(() => {});

  const { token } = await createSession(
    user.id,
    ip,
    req.headers.get("user-agent") ?? ""
  );

  const res = ok({ user: publicUser(user) });
  res.cookies.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_TTL_MS / 1000,
  });
  return res;
}
