/**
 * Cloudflare 部署资产：这些字符串会展示在「部署教程」标签页中，
 * 供用户复制 / 下载后直接部署到 Cloudflare Workers + D1。
 */

/** wrangler.toml — Cloudflare Workers 项目配置 */
export const WRANGLER_TOML = `# wrangler.toml — Cloudflare Workers 配置文件
name = "cloudauth-account-system"   # Worker 名称（决定 workers.dev 子域名）
main = "src/worker.js"              # 入口文件
compatibility_date = "2025-06-01"   # 兼容日期，一般取近期日期即可

# ★ D1 数据库绑定
# 把 database_id 替换为第 2 步执行 wrangler d1 create 后得到的真实 ID
[[d1_databases]]
binding = "DB"                      # Worker 代码中通过 env.DB 访问
database_name = "cloudauth-db"
database_id = "把这里替换为你的-database-id"
`;

/** schema.sql — D1 数据库表结构（SQLite 方言） */
export const SCHEMA_SQL = `-- schema.sql — 账户系统表结构（D1 兼容 SQLite）
-- 用户表
CREATE TABLE IF NOT EXISTS users (
  id            TEXT PRIMARY KEY,
  username      TEXT NOT NULL UNIQUE,      -- 用户名：字母开头，3-20 位
  email         TEXT NOT NULL UNIQUE,      -- 邮箱（统一小写存储）
  password_hash TEXT NOT NULL,             -- PBKDF2-SHA256(密码, 盐)，永不明文
  nickname      TEXT,                      -- 昵称（可空）
  register_ip   TEXT NOT NULL,             -- 注册时使用的客户端 IP
  created_at    TEXT NOT NULL,
  updated_at    TEXT NOT NULL
);

-- 会话表：HttpOnly Cookie 指向这里的 token
CREATE TABLE IF NOT EXISTS sessions (
  token      TEXT PRIMARY KEY,
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  ip         TEXT,
  user_agent TEXT,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL
);

-- IP 注册记录表：实现「每个 IP 最多注册 3 个账户」的核心
CREATE TABLE IF NOT EXISTS ip_registrations (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  ip         TEXT NOT NULL,
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL
);

-- 索引：按 IP 统计注册数是高频查询
CREATE INDEX IF NOT EXISTS idx_ip_registrations_ip ON ip_registrations(ip);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
`;

/** worker.js — 完整可部署的账户系统 Worker（Cloudflare Workers + D1） */
export const WORKER_JS = `/**
 * 云鉴 CloudAuth — 基于 Cloudflare Workers + D1 的账户系统
 *
 * 功能：
 *   1. 注册 / 登录 / 登出 / 查询当前用户
 *   2. 会话管理（HttpOnly Cookie，多设备列表与注销）
 *   3. ★ 同一 IP 最多注册 3 个账户（防滥用，可修改常量）
 *   4. 密码使用 PBKDF2-SHA256（10 万次迭代 + 16 字节随机盐）存储
 *
 * 数据表：users / sessions / ip_registrations（见 schema.sql）
 * 部署方法见配套教程。
 */

const MAX_ACCOUNTS_PER_IP = 3;           // ★ 每个 IP 最多注册的账户数
const SESSION_TTL_SECONDS = 7 * 24 * 60 * 60; // 会话有效期：7 天
const PBKDF2_ITERATIONS = 100000;
const COOKIE_NAME = 'session_token';

/* ---------------- HTTP 工具函数 ---------------- */

function json(data, status, headers) {
  return new Response(JSON.stringify(data, null, 2), {
    status: status || 200,
    headers: Object.assign(
      { 'Content-Type': 'application/json; charset=utf-8' },
      headers || {}
    ),
  });
}

function ok(data, headers) {
  return json({ success: true, data: data }, 200, headers);
}

function fail(status, code, message, extra, headers) {
  const error = Object.assign({ code: code, message: message }, extra || {});
  return json({ success: false, error: error }, status, headers);
}

/** Cloudflare 边缘网络注入的真实客户端 IP，无法伪造 */
function getClientIp(request) {
  return request.headers.get('CF-Connecting-IP') || '0.0.0.0';
}

function newToken() {
  return (crypto.randomUUID() + crypto.randomUUID()).replace(/-/g, '');
}

function getCookie(request, name) {
  const parts = (request.headers.get('Cookie') || '').split(';');
  for (const part of parts) {
    const idx = part.indexOf('=');
    if (idx === -1) continue;
    if (part.slice(0, idx).trim() === name) return part.slice(idx + 1).trim();
  }
  return null;
}

function sessionCookie(token) {
  return COOKIE_NAME + '=' + token +
    '; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=' + SESSION_TTL_SECONDS;
}

function clearSessionCookie() {
  return COOKIE_NAME + '=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0';
}

function maskIp(ip) {
  if (ip.includes(':')) {
    const parts = ip.split(':').filter(Boolean);
    return parts.length >= 2 ? parts.slice(0, 2).join(':') + '::****' : ip;
  }
  const parts = ip.split('.');
  if (parts.length === 4) return parts[0] + '.' + parts[1] + '.**.**';
  return ip;
}

/* ------------- 密码哈希：Web Crypto PBKDF2-SHA256 ------------- */

async function hashPassword(password, salt) {
  const encoder = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey(
    'raw', encoder.encode(password), 'PBKDF2', false, ['deriveBits']
  );
  const bits = await crypto.subtle.deriveBits(
    {
      name: 'PBKDF2',
      salt: encoder.encode(salt),
      iterations: PBKDF2_ITERATIONS,
      hash: 'SHA-256',
    },
    keyMaterial,
    256
  );
  const hash = Array.from(new Uint8Array(bits))
    .map(function (b) { return b.toString(16).padStart(2, '0'); })
    .join('');
  return 'pbkdf2:' + PBKDF2_ITERATIONS + ':' + salt + ':' + hash;
}

async function verifyPassword(password, stored) {
  const parts = stored.split(':');
  if (parts.length !== 4) return false;
  const recomputed = await hashPassword(password, parts[2]);
  return recomputed.split(':')[3] === parts[3];
}

/* ---------------- 数据访问层（D1） ---------------- */

async function countIpRegistrations(env, ip) {
  const row = await env.DB.prepare(
    'SELECT COUNT(*) AS c FROM ip_registrations WHERE ip = ?'
  ).bind(ip).first();
  return row ? row.c : 0;
}

async function createSession(env, request, userId, ip) {
  const token = newToken();
  const now = new Date().toISOString();
  const expiresAt = new Date(Date.now() + SESSION_TTL_SECONDS * 1000).toISOString();
  await env.DB.prepare(
    'INSERT INTO sessions (token, user_id, ip, user_agent, created_at, expires_at) ' +
    'VALUES (?, ?, ?, ?, ?, ?)'
  ).bind(token, userId, ip, request.headers.get('User-Agent') || '', now, expiresAt).run();
  return token;
}

async function getAuth(request, env) {
  const token = getCookie(request, COOKIE_NAME);
  if (!token) return null;
  const session = await env.DB.prepare(
    'SELECT token, user_id, expires_at FROM sessions WHERE token = ?'
  ).bind(token).first();
  if (!session) return null;
  if (new Date(session.expires_at).getTime() < Date.now()) {
    await env.DB.prepare('DELETE FROM sessions WHERE token = ?').bind(token).run();
    return null;
  }
  const user = await env.DB.prepare(
    'SELECT id, username, email, nickname, register_ip, created_at FROM users WHERE id = ?'
  ).bind(session.user_id).first();
  return user ? { user: user, token: token } : null;
}

function publicUser(row, needMask) {
  return {
    id: row.id,
    username: row.username,
    email: row.email,
    nickname: row.nickname,
    registerIp: needMask ? maskIp(row.register_ip) : row.register_ip,
    createdAt: row.created_at,
  };
}

/* ---------------- 路由处理 ---------------- */

async function handle(request, env) {
  const url = new URL(request.url);
  const path = url.pathname;
  const method = request.method;

  /* ---------- POST /api/auth/register 注册 ---------- */
  if (method === 'POST' && path === '/api/auth/register') {
    const body = await request.json().catch(function () { return null; });
    const b = body || {};
    const username = String(b.username || '').trim();
    const email = String(b.email || '').trim().toLowerCase();
    const password = String(b.password || '');
    const nickname = String(b.nickname || '').trim() || null;

    if (!/^[a-zA-Z][a-zA-Z0-9_]{2,19}$/.test(username)) {
      return fail(400, 'INVALID_INPUT', '用户名需以字母开头，3-20 位，仅支持字母、数字、下划线');
    }
    if (!/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(email)) {
      return fail(400, 'INVALID_INPUT', '邮箱格式不正确');
    }
    if (password.length < 8) {
      return fail(400, 'INVALID_INPUT', '密码长度至少 8 位');
    }

    const ip = getClientIp(request);

    // ★ 核心：同一 IP 最多注册 3 个账户
    const used = await countIpRegistrations(env, ip);
    if (used >= MAX_ACCOUNTS_PER_IP) {
      return fail(
        429, 'IP_LIMIT_EXCEEDED',
        '该 IP 地址最多可注册 ' + MAX_ACCOUNTS_PER_IP + ' 个账户，已达上限',
        { ip: ip, limit: MAX_ACCOUNTS_PER_IP, used: used }
      );
    }

    const usernameTaken = await env.DB.prepare(
      'SELECT id FROM users WHERE username = ?'
    ).bind(username).first();
    if (usernameTaken) return fail(409, 'USERNAME_EXISTS', '用户名已被注册');

    const emailTaken = await env.DB.prepare(
      'SELECT id FROM users WHERE email = ?'
    ).bind(email).first();
    if (emailTaken) return fail(409, 'EMAIL_EXISTS', '邮箱已被注册');

    // 写入用户 + IP 注册记录 + 会话（注册即登录）
    const id = crypto.randomUUID();
    const now = new Date().toISOString();
    const passwordHash = await hashPassword(password, newToken().slice(0, 32));

    await env.DB.prepare(
      'INSERT INTO users (id, username, email, password_hash, nickname, register_ip, created_at, updated_at) ' +
      'VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
    ).bind(id, username, email, passwordHash, nickname, ip, now, now).run();

    await env.DB.prepare(
      'INSERT INTO ip_registrations (ip, user_id, created_at) VALUES (?, ?, ?)'
    ).bind(ip, id, now).run();

    const token = await createSession(env, request, id, ip);

    return ok(
      {
        user: {
          id: id, username: username, email: email,
          nickname: nickname, registerIp: ip, createdAt: now,
        },
        ip: { address: ip, used: used + 1, limit: MAX_ACCOUNTS_PER_IP },
      },
      { 'Set-Cookie': sessionCookie(token) }
    );
  }

  /* ---------- POST /api/auth/login 登录 ---------- */
  if (method === 'POST' && path === '/api/auth/login') {
    const body = await request.json().catch(function () { return null; });
    const identifier = String(((body || {}).identifier) || '').trim();
    const password = String(((body || {}).password) || '');
    if (!identifier || !password) {
      return fail(400, 'INVALID_INPUT', '请输入账号和密码');
    }

    const row = identifier.includes('@')
      ? await env.DB.prepare('SELECT * FROM users WHERE email = ?')
          .bind(identifier.toLowerCase()).first()
      : await env.DB.prepare('SELECT * FROM users WHERE username = ?')
          .bind(identifier).first();

    if (!row || !(await verifyPassword(password, row.password_hash))) {
      return fail(401, 'INVALID_CREDENTIALS', '账号或密码错误');
    }

    const ip = getClientIp(request);
    const token = await createSession(env, request, row.id, ip);
    return ok({ user: publicUser(row, false) }, { 'Set-Cookie': sessionCookie(token) });
  }

  /* ---------- POST /api/auth/logout 登出 ---------- */
  if (method === 'POST' && path === '/api/auth/logout') {
    const token = getCookie(request, COOKIE_NAME);
    if (token) {
      await env.DB.prepare('DELETE FROM sessions WHERE token = ?').bind(token).run();
    }
    return ok({ message: '已退出登录' }, { 'Set-Cookie': clearSessionCookie() });
  }

  /* ---------- GET /api/auth/me 当前用户 ---------- */
  if (method === 'GET' && path === '/api/auth/me') {
    const auth = await getAuth(request, env);
    if (!auth) return fail(401, 'UNAUTHORIZED', '未登录或会话已过期');
    const ip = getClientIp(request);
    const used = await countIpRegistrations(env, ip);
    return ok({
      user: publicUser(auth.user, true),
      ip: { address: ip, used: used, limit: MAX_ACCOUNTS_PER_IP },
    });
  }

  /* ---------- GET /api/ip-usage IP 配额 ---------- */
  if (method === 'GET' && path === '/api/ip-usage') {
    const ip = getClientIp(request);
    const used = await countIpRegistrations(env, ip);
    return ok({
      ip: ip, used: used, limit: MAX_ACCOUNTS_PER_IP,
      remaining: Math.max(0, MAX_ACCOUNTS_PER_IP - used),
    });
  }

  /* ---------- PATCH /api/account/profile 更新资料 ---------- */
  if (method === 'PATCH' && path === '/api/account/profile') {
    const auth = await getAuth(request, env);
    if (!auth) return fail(401, 'UNAUTHORIZED', '未登录或会话已过期');
    const body = await request.json().catch(function () { return null; });
    const nickname = String(((body || {}).nickname) || '').trim();
    if (nickname.length > 20) {
      return fail(400, 'INVALID_INPUT', '昵称长度不能超过 20 个字符');
    }
    await env.DB.prepare('UPDATE users SET nickname = ?, updated_at = ? WHERE id = ?')
      .bind(nickname || null, new Date().toISOString(), auth.user.id).run();
    return ok({ message: '资料已更新', nickname: nickname || null });
  }

  /* ---------- GET /api/account/sessions 会话列表 ---------- */
  if (method === 'GET' && path === '/api/account/sessions') {
    const auth = await getAuth(request, env);
    if (!auth) return fail(401, 'UNAUTHORIZED', '未登录或会话已过期');
    const rows = await env.DB.prepare(
      'SELECT token, ip, user_agent, created_at, expires_at FROM sessions ' +
      'WHERE user_id = ? ORDER BY created_at DESC'
    ).bind(auth.user.id).all();
    const sessions = (rows.results || []).map(function (s) {
      return {
        ip: maskIp(s.ip || '未知'),
        userAgent: s.user_agent || '',
        createdAt: s.created_at,
        expiresAt: s.expires_at,
        current: s.token === auth.token,
      };
    });
    return ok({ sessions: sessions });
  }

  /* ---------- DELETE /api/account/sessions 注销其他会话 ---------- */
  if (method === 'DELETE' && path === '/api/account/sessions') {
    const auth = await getAuth(request, env);
    if (!auth) return fail(401, 'UNAUTHORIZED', '未登录或会话已过期');
    await env.DB.prepare('DELETE FROM sessions WHERE user_id = ? AND token != ?')
      .bind(auth.user.id, auth.token).run();
    return ok({ message: '已注销其他所有会话' });
  }

  return fail(404, 'NOT_FOUND', '接口不存在：' + method + ' ' + path);
}

export default {
  async fetch(request, env, ctx) {
    try {
      return await handle(request, env);
    } catch (err) {
      return fail(500, 'INTERNAL_ERROR', '服务器内部错误：' + String((err && err.message) || err));
    }
  },
};
`;

/** 教程中用到的命令片段 */
export const TUTORIAL_SNIPPETS = {
  installWrangler: `# 安装 Wrangler 命令行工具（Node.js 18+）
npm install -g wrangler

# 登录 Cloudflare（会打开浏览器授权）
wrangler login

# 验证登录状态
wrangler whoami`,

  createDb: `# 创建 D1 数据库
wrangler d1 create cloudauth-db

# 执行后会输出类似内容，记下其中的 database_id：
# ✅ Successfully created DB if not exists: cloudauth-db
# [[d1_databases]]
# binding = "DB"
# database_name = "cloudauth-db"
# database_id = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"   ← 复制这个 ID`,

  initTables: `# 在本地（开发环境）初始化表结构
wrangler d1 execute cloudauth-db --local --file=./schema.sql

# 在远程（生产环境）初始化表结构
wrangler d1 execute cloudauth-db --remote --file=./schema.sql

# 验证：查看所有表（--remote 查询线上库）
wrangler d1 execute cloudauth-db --remote \\
  --command "SELECT name FROM sqlite_master WHERE type='table'"`,

  localDev: `# 启动本地开发服务器（默认监听 http://localhost:8787，自动使用本地 D1）
wrangler dev

# 另开一个终端测试注册（-c 保存 Cookie 便于后续调用需登录接口）
curl -X POST http://localhost:8787/api/auth/register \\
  -H "Content-Type: application/json" \\
  -c cookies.txt \\
  -d '{"username":"demo","email":"demo@example.com","password":"demo12345","nickname":"演示用户"}'

# 测试登录
curl -X POST http://localhost:8787/api/auth/login \\
  -H "Content-Type: application/json" \\
  -c cookies.txt \\
  -d '{"identifier":"demo","password":"demo12345"}'

# 用保存的 Cookie 查询当前用户
curl http://localhost:8787/api/auth/me -b cookies.txt`,

  deploy: `# 部署到 Cloudflare 全球边缘网络
wrangler deploy

# 成功后会输出：
# Published cloudauth-account-system (x.xx sec)
#   https://cloudauth-account-system.<你的子域>.workers.dev   ← 这就是线上地址

# 线上验证（把域名替换成你的 workers.dev 地址）
curl https://cloudauth-account-system.your-subdomain.workers.dev/api/ip-usage`,

  d1Ops: `# 查询用户数
wrangler d1 execute cloudauth-db --remote \\
  --command "SELECT COUNT(*) AS total_users FROM users"

# 查看某个 IP 注册了几个账户
wrangler d1 execute cloudauth-db --remote \\
  --command "SELECT ip, COUNT(*) AS n FROM ip_registrations GROUP BY ip"

# 导出数据库备份（D1 内置导出）
wrangler d1 export cloudauth-db --remote --output=./backup.sql

# 删除某个用户（演示）
wrangler d1 execute cloudauth-db --remote \\
  --command "DELETE FROM users WHERE username = 'demo'"`,
};
