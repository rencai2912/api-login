"use client";

import * as React from "react";
import { Cloud, Home, BookOpen, Rocket } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ThemeToggle } from "@/components/theme-toggle";
import { HomeTab } from "./home-tab";
import { ApiDocsTab } from "./api-docs-tab";
import { TutorialTab } from "./tutorial-tab";

export function SiteShell() {
  const [tab, setTab] = React.useState("home");

  return (
    <Tabs
      value={tab}
      onValueChange={setTab}
      className="flex min-h-screen flex-col bg-background"
    >
      {/* ============ 页头（吸顶） ============ */}
      <header className="sticky top-0 z-40 border-b bg-background/85 backdrop-blur supports-[backdrop-filter]:bg-background/70">
        <div className="mx-auto flex h-16 w-full max-w-6xl items-center gap-2 px-4 sm:gap-4">
          {/* Logo */}
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-sm">
              <Cloud className="h-5 w-5" aria-hidden />
            </div>
            <div className="leading-tight">
              <p className="text-sm font-bold tracking-tight">云鉴 CloudAuth</p>
              <p className="hidden text-[10px] text-muted-foreground sm:block">
                Cloudflare Workers + D1 账户系统
              </p>
            </div>
          </div>

          {/* 导航标签 */}
          <nav
            className="ml-auto min-w-0"
            aria-label="主导航"
          >
            <TabsList className="h-10 max-w-full gap-1 overflow-x-auto bg-muted/60 p-1">
              <TabsTrigger
                value="home"
                className="gap-1.5 px-3 text-xs sm:text-sm"
              >
                <Home className="h-4 w-4" />
                <span className="hidden sm:inline">首页</span>
                <span className="sm:hidden">首页</span>
              </TabsTrigger>
              <TabsTrigger
                value="docs"
                className="gap-1.5 px-3 text-xs sm:text-sm"
              >
                <BookOpen className="h-4 w-4" />
                <span className="hidden sm:inline">API 文档</span>
                <span className="sm:hidden">文档</span>
              </TabsTrigger>
              <TabsTrigger
                value="tutorial"
                className="gap-1.5 px-3 text-xs sm:text-sm"
              >
                <Rocket className="h-4 w-4" />
                <span className="hidden sm:inline">部署教程</span>
                <span className="sm:hidden">教程</span>
              </TabsTrigger>
            </TabsList>
          </nav>

          {/* 主题切换 */}
          <div className="shrink-0">
            <ThemeToggle />
          </div>
        </div>
      </header>

      {/* ============ 主体内容 ============ */}
      <main className="flex-1">
        <TabsContent value="home" className="m-0">
          <div className="px-4 py-10 sm:py-14">
            <HomeTab />
          </div>
        </TabsContent>

        <TabsContent value="docs" className="m-0">
          <div className="px-4 py-10 sm:py-12">
            <ApiDocsTab />
          </div>
        </TabsContent>

        <TabsContent value="tutorial" className="m-0">
          <div className="px-4 py-10 sm:py-12">
            <TutorialTab />
          </div>
        </TabsContent>
      </main>

      {/* ============ 页脚（吸底） ============ */}
      <footer className="mt-auto border-t bg-muted/40">
        <div className="mx-auto flex w-full max-w-6xl flex-col items-center justify-between gap-3 px-4 py-6 text-center text-xs text-muted-foreground sm:flex-row sm:text-left">
          <div className="flex items-center gap-2">
            <Cloud className="h-4 w-4 text-primary" aria-hidden />
            <span className="font-medium">云鉴 CloudAuth</span>
            <span>· 轻量级账户系统演示</span>
          </div>
          <p>
            Cloudflare Workers + D1 参考实现 · 同一 IP 最多注册 3 个账户 ·
            密码加盐哈希存储
          </p>
          <p>仅供学习与演示，请勿存放真实密码</p>
        </div>
      </footer>
    </Tabs>
  );
}
