"use client";

import * as React from "react";
import {
  Rocket,
  Database,
  FolderTree,
  Cloud,
  Play,
  UploadCloud,
  Wrench,
  HelpCircle,
  CheckCircle2,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { CodeBlock } from "@/components/code-block";
import {
  WRANGLER_TOML,
  SCHEMA_SQL,
  WORKER_JS,
  TUTORIAL_SNIPPETS,
} from "./cloudflare-assets";

/* 步骤定义 */
interface Step {
  no: number;
  icon: React.ElementType;
  title: string;
  desc: React.ReactNode;
}

function StepHeader({
  step,
  last,
}: {
  step: Step;
  last?: boolean;
}) {
  return (
    <div className="relative flex gap-4 pb-6">
      {/* 时间线圆点与竖线 */}
      <div className="flex flex-col items-center">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-sm">
          <step.icon className="h-5 w-5" />
        </div>
        {!last && (
          <div className="mt-2 w-px flex-1 bg-gradient-to-b from-orange-500/40 to-border" />
        )}
      </div>
      <div className="space-y-3 pt-1">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wide text-primary">
            第 {step.no} 步
          </p>
          <h2 className="mt-0.5 text-lg font-bold tracking-tight">{step.title}</h2>
        </div>
        <div className="space-y-4 text-sm leading-relaxed text-muted-foreground">
          {step.desc}
        </div>
      </div>
    </div>
  );
}

/* ================================================================ */
/*                         部署教程 Tab                              */
/* ================================================================ */

export function TutorialTab() {
  return (
    <div className="mx-auto w-full max-w-4xl space-y-8">
      {/* 教程头部 */}
      <header className="space-y-3">
        <div className="flex items-center gap-2">
          <Rocket className="h-5 w-5 text-primary" />
          <h1 className="text-2xl font-bold tracking-tight">
            Cloudflare D1 数据库配置与部署教程
          </h1>
        </div>
        <p className="max-w-3xl text-sm leading-relaxed text-muted-foreground">
          按照下面的步骤，把本账户系统原样部署到 Cloudflare：
          使用 <b>D1（Cloudflare 内置的无服务器 SQLite 数据库）</b>
          存储用户、会话与 IP 注册记录，使用 Workers 在全球边缘节点运行 API。
          全程免费套餐即可完成，预计 15 分钟。
        </p>
        <Alert>
          <CheckCircle2 className="h-4 w-4" />
          <AlertTitle>先收藏三个文件</AlertTitle>
          <AlertDescription>
            教程中的 wrangler.toml、schema.sql、worker.js
            都支持一键复制或下载，分别对应：Worker 配置、D1 建表语句、完整业务代码。
            最后一步执行 <code className="font-mono text-xs">wrangler deploy</code>{" "}
            即可上线。
          </AlertDescription>
        </Alert>
      </header>

      {/* 步骤时间线 */}
      <div className="space-y-2">
        {/* 第 1 步 */}
        <StepHeader
          step={{
            no: 1,
            icon: Cloud,
            title: "准备工作：注册账号并安装 Wrangler",
            desc: (
              <>
                <p>
                  1. 访问 dash.cloudflare.com 注册一个 Cloudflare
                  账号（免费版即可，无需绑定信用卡）。
                </p>
                <p>
                  2. 本机安装 Node.js 18+，然后安装官方命令行工具 Wrangler：
                </p>
                <CodeBlock
                  code={TUTORIAL_SNIPPETS.installWrangler}
                  language="bash"
                  title="终端"
                />
              </>
            ),
          }}
        />

        {/* 第 2 步 */}
        <StepHeader
          step={{
            no: 2,
            icon: Database,
            title: "创建 D1 数据库（关键步骤）",
            desc: (
              <>
                <p>
                  D1 是 Cloudflare 托管的无服务器 SQLite
                  数据库，与应用一起运行在边缘网络。执行以下命令创建：
                </p>
                <CodeBlock
                  code={TUTORIAL_SNIPPETS.createDb}
                  language="bash"
                  title="终端"
                />
                <p>
                  <b>也可以在控制台界面创建：</b>登录 Dashboards → 左侧{" "}
                  <b>Workers 和 Pages</b> → <b>D1 SQL 数据库</b> →{" "}
                  <b>创建数据库</b>，名称填 <code className="font-mono text-xs">cloudauth-db</code>。
                </p>
                <Alert variant="default" className="py-3">
                  <HelpCircle className="h-4 w-4" />
                  <AlertTitle>免费套餐额度</AlertTitle>
                  <AlertDescription>
                    D1 免费版：5 GB 存储 / 每天 500 万行读取 / 每天 10 万行写入，对账户系统绰绰有余；
                    超额后再按用量计费。
                  </AlertDescription>
                </Alert>
              </>
            ),
          }}
        />

        {/* 第 3 步 */}
        <StepHeader
          step={{
            no: 3,
            icon: FolderTree,
            title: "创建项目并写入配置文件",
            desc: (
              <>
                <p>
                  新建一个项目文件夹，结构如下（worker.js 的完整内容见第 5 步）：
                </p>
                <CodeBlock
                  title="项目结构"
                  language="text"
                  highlight={false}
                  code={`cloudauth/
├── wrangler.toml    # Workers 配置（绑定 D1）
├── schema.sql       # 建表语句
└── src/
    └── worker.js    # 账户系统全部业务代码`}
                />
                <p>
                  编辑 <code className="font-mono text-xs">wrangler.toml</code>，
                  将第 2 步得到的 database_id 填进去：
                </p>
                <CodeBlock
                  code={WRANGLER_TOML}
                  language="toml"
                  title="wrangler.toml"
                  downloadAs="wrangler.toml"
                />
              </>
            ),
          }}
        />

        {/* 第 4 步 */}
        <StepHeader
          step={{
            no: 4,
            icon: Database,
            title: "初始化数据库表结构",
            desc: (
              <>
                <p>
                  把下面的 SQL 保存为项目根目录的{" "}
                  <code className="font-mono text-xs">schema.sql</code>，
                  它创建了三张表：<b>users</b>（用户）、<b>sessions</b>（会话）、
                  <b>ip_registrations</b>（IP 注册记录，「每个 IP 最多 3
                  个账户」就靠它统计）：
                </p>
                <CodeBlock
                  code={SCHEMA_SQL}
                  language="sql"
                  title="schema.sql"
                  downloadAs="schema.sql"
                  maxHeightClass="max-h-[26rem]"
                />
                <p>分别对本地库和线上库执行建表脚本：</p>
                <CodeBlock
                  code={TUTORIAL_SNIPPETS.initTables}
                  language="bash"
                  title="终端"
                />
                <p>
                  执行成功后会看到{" "}
                  <code className="font-mono text-xs">users、sessions、ip_registrations、sqlite_master</code>{" "}
                  等表名，说明数据库初始化完成。
                </p>
              </>
            ),
          }}
        />

        {/* 第 5 步 */}
        <StepHeader
          step={{
            no: 5,
            icon: Wrench,
            title: "写入 Worker 业务代码",
            desc: (
              <>
                <p>
                  将以下代码保存为{" "}
                  <code className="font-mono text-xs">src/worker.js</code>。它实现了与本演示站完全一致的
                  8 个接口：注册（含 IP 限制）、登录、登出、查询用户、IP
                  配额、资料更新、会话管理，全部单文件、零依赖。
                </p>
                <CodeBlock
                  code={WORKER_JS}
                  language="javascript"
                  title="src/worker.js"
                  downloadAs="worker.js"
                  maxHeightClass="max-h-[32rem]"
                />
                <p className="text-xs">
                  代码要点：通过{" "}
                  <code className="font-mono text-xs">env.DB.prepare(...).bind(...)</code>{" "}
                  操作 D1；真实客户端 IP 取{" "}
                  <code className="font-mono text-xs">CF-Connecting-IP</code>{" "}
                  请求头（Cloudflare 边缘注入、无法伪造）；密码用 Web Crypto
                  PBKDF2-SHA256（10 万次迭代）加盐哈希后存入{" "}
                  <code className="font-mono text-xs">password_hash</code> 字段。
                </p>
              </>
            ),
          }}
        />

        {/* 第 6 步 */}
        <StepHeader
          step={{
            no: 6,
            icon: Play,
            title: "本地开发与调试",
            desc: (
              <>
                <p>
                  启动本地开发服务器（Wrangler 会自动使用 --local
                  的本地 D1 数据库，不消耗线上额度）：
                </p>
                <CodeBlock
                  code={TUTORIAL_SNIPPETS.localDev}
                  language="bash"
                  title="终端"
                />
                <p>
                  注册 3 个账户后，第 4 次注册会返回{" "}
                  <code className="font-mono text-xs">429 IP_LIMIT_EXCEEDED</code>
                  ——限制功能与线上一致。
                </p>
              </>
            ),
          }}
        />

        {/* 第 7 步 */}
        <StepHeader
          step={{
            no: 7,
            icon: UploadCloud,
            title: "部署到 Cloudflare 全球边缘网络",
            desc: (
              <>
                <p>一条命令上线：</p>
                <CodeBlock
                  code={TUTORIAL_SNIPPETS.deploy}
                  language="bash"
                  title="终端"
                />
                <p>
                  绑定自定义域名（可选）：Dashboard → 你的 Worker →{" "}
                  <b>设置 → 域名和路由 → 添加自定义域</b>，填入你在
                  Cloudflare 托管的域名即可自动配置 HTTPS。
                </p>
              </>
            ),
          }}
        />

        {/* 第 8 步 */}
        <StepHeader
          step={{
            no: 8,
            icon: Database,
            title: "D1 日常运维（增删改查 / 备份）",
            desc: (
              <>
                <p>部署完成后，随时可以用命令行操作 D1 数据库：</p>
                <CodeBlock code={TUTORIAL_SNIPPETS.d1Ops} language="bash" title="终端" />
                <p className="text-xs">
                  此外 D1 内置 <b>Time Travel</b> 时间旅行功能（Beta），可一键把数据库回滚到
                  30 天内任意时刻的状态：Dashboard → D1 数据库 → Time Travel，适合误删数据后的快速恢复。
                </p>
              </>
            ),
          }}
          last
        />
      </div>

      {/* FAQ */}
      <section className="space-y-4">
        <h2 className="flex items-center gap-2 text-lg font-semibold">
          <HelpCircle className="h-5 w-5 text-primary" />
          常见问题（FAQ）
        </h2>
        <div className="grid gap-4 sm:grid-cols-2">
          {[
            {
              q: "生产环境如何获取访客真实 IP？",
              a: "Cloudflare 在每个请求中注入 CF-Connecting-IP 头，且无法被客户端伪造。Worker 代码已默认读取该头；本演示站（Next.js）则读取 X-Forwarded-IP / X-Forwarded-For。",
            },
            {
              q: "每个 IP 只能注册 3 个账户，能改吗？",
              a: "能。修改 worker.js 顶部的 MAX_ACCOUNTS_PER_IP 常量后重新 wrangler deploy 即可，无需改动数据库。",
            },
            {
              q: "密码是明文存储吗？",
              a: "不是。Worker 版使用 Web Crypto 的 PBKDF2-SHA256（10 万次迭代 + 16 字节随机盐）哈希，D1 中只保存 pbkdf2:迭代数:盐:哈希 四段式字符串。",
            },
            {
              q: "会话存在哪里？安全吗？",
              a: "D1 的 sessions 表，Cookie 采用 HttpOnly + Secure + SameSite=Lax，有效期 7 天，支持多设备管理与一键注销。需要更高性能时也可把会话迁移到 Workers KV。",
            },
            {
              q: "如何防止脚本绕过注册接口？",
              a: "建议接入 Cloudflare Turnstile（免费人机验证），在注册接口校验 turnstile token；也可叠加速率限制（本演示已内置每 IP 每 10 分钟 10 次的注册限流）。",
            },
            {
              q: "为什么本地 dev 和线上数据不一样？",
              a: "wrangler dev 默认使用 --local 本地 D1（存在 .wrangler/state 中），与线上库互不影响；用 wrangler d1 execute 加 --remote 才操作线上库。",
            },
          ].map((item) => (
            <Card key={item.q} className="bg-card/70">
              <CardContent className="space-y-2 p-5">
                <h3 className="text-sm font-semibold">{item.q}</h3>
                <p className="text-xs leading-relaxed text-muted-foreground">{item.a}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    </div>
  );
}
