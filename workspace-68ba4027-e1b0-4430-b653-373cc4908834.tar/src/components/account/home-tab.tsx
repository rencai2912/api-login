"use client";

import * as React from "react";
import { motion } from "framer-motion";
import {
  Cloud,
  ShieldCheck,
  KeyRound,
  Cookie,
  BookOpen,
  LogIn,
  UserPlus,
  LogOut,
  Loader2,
  Globe2,
  History,
  Trash2,
  Pencil,
  Check,
  X,
  MonitorSmartphone,
  FlaskConical,
  Fingerprint,
  Database,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import type {
  ApiEnvelope,
  IpUsageData,
  MeData,
  SessionInfo,
} from "@/types/account";

/* ---------------- 通用请求封装 ---------------- */

async function api<T>(
  path: string,
  init?: RequestInit
): Promise<ApiEnvelope<T>> {
  try {
    const res = await fetch(path, {
      credentials: "same-origin",
      ...init,
      headers: {
        ...(init?.body ? { "Content-Type": "application/json" } : {}),
        ...init?.headers,
      },
    });
    return (await res.json()) as ApiEnvelope<T>;
  } catch {
    return {
      success: false,
      error: { code: "NETWORK_ERROR", message: "网络错误，请稍后重试" },
    };
  }
}

const USERNAME_RE = /^[a-zA-Z][a-zA-Z0-9_]{2,19}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function formatTime(t: string) {
  return new Date(t).toLocaleString("zh-CN", { hour12: false });
}

/** 从 User-Agent 提取简洁的设备描述 */
function describeUa(ua: string) {
  if (!ua) return "未知设备";
  let os = "未知系统";
  if (/Windows/i.test(ua)) os = "Windows";
  else if (/Android/i.test(ua)) os = "Android";
  else if (/iPhone|iPad/i.test(ua)) os = "iOS";
  else if (/Mac OS X/i.test(ua)) os = "macOS";
  else if (/Linux/i.test(ua)) os = "Linux";

  let browser = "浏览器";
  if (/Edg\//i.test(ua)) browser = "Edge";
  else if (/Chrome\//i.test(ua)) browser = "Chrome";
  else if (/Firefox\//i.test(ua)) browser = "Firefox";
  else if (/Safari\//i.test(ua) && !/Chrome/i.test(ua)) browser = "Safari";

  return `${browser} · ${os}`;
}

/* ---------------- 特性列表 ---------------- */

const FEATURES = [
  {
    icon: ShieldCheck,
    title: "IP 注册限制",
    desc: "同一 IP 最多注册 3 个账户，从源头防止批量注册滥用",
  },
  {
    icon: KeyRound,
    title: "密码安全存储",
    desc: "PBKDF2-SHA256 十万次迭代加盐哈希，数据库不存明文",
  },
  {
    icon: Cookie,
    title: "会话管理",
    desc: "HttpOnly Cookie 会话，支持多设备查看与一键注销",
  },
  {
    icon: BookOpen,
    title: "开放 REST API",
    desc: "内置完整中文接口文档与 Cloudflare D1 部署教程",
  },
];

/* ================================================================ */
/*                      登录 / 注册卡片                              */
/* ================================================================ */

interface AuthCardProps {
  ipUsage: IpUsageData | null;
  onAuthed: () => void;
  onReset: () => void;
}

function AuthCard({ ipUsage, onAuthed, onReset }: AuthCardProps) {
  const { toast } = useToast();
  const [mode, setMode] = React.useState<"login" | "register">("login");

  // 公共状态
  const [submitting, setSubmitting] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  // 登录表单
  const [identifier, setIdentifier] = React.useState("");
  const [password, setPassword] = React.useState("");

  // 注册表单
  const [regUsername, setRegUsername] = React.useState("");
  const [regEmail, setRegEmail] = React.useState("");
  const [regNickname, setRegNickname] = React.useState("");
  const [regPassword, setRegPassword] = React.useState("");
  const [regConfirm, setRegConfirm] = React.useState("");

  const limitReached = (ipUsage?.used ?? 0) >= (ipUsage?.limit ?? 3);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!identifier.trim() || !password) {
      setError("请输入账号和密码");
      return;
    }
    setSubmitting(true);
    const res = await api<{ user: unknown }>("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({ identifier: identifier.trim(), password }),
    });
    setSubmitting(false);
    if (res.success) {
      toast({ title: "登录成功", description: "欢迎回来！" });
      onAuthed();
    } else {
      setError(res.error?.message ?? "登录失败");
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!USERNAME_RE.test(regUsername)) {
      setError("用户名需以字母开头，3-20 位，仅支持字母、数字、下划线");
      return;
    }
    if (!EMAIL_RE.test(regEmail)) {
      setError("邮箱格式不正确");
      return;
    }
    if (regPassword.length < 8) {
      setError("密码长度至少 8 位");
      return;
    }
    if (regPassword !== regConfirm) {
      setError("两次输入的密码不一致");
      return;
    }
    setSubmitting(true);
    const res = await api("/api/auth/register", {
      method: "POST",
      body: JSON.stringify({
        username: regUsername,
        email: regEmail,
        nickname: regNickname,
        password: regPassword,
      }),
    });
    setSubmitting(false);
    if (res.success) {
      toast({ title: "注册成功", description: "已自动登录，欢迎加入！" });
      onAuthed();
    } else {
      setError(res.error?.message ?? "注册失败");
    }
  };

  return (
    <Card className="w-full border-border/80 shadow-lg shadow-orange-500/5">
      <CardHeader className="space-y-1 pb-2">
        <CardTitle className="flex items-center gap-2 text-xl">
          <Globe2 className="h-5 w-5 text-primary" />
          {mode === "login" ? "登录账户" : "创建账户"}
        </CardTitle>
        <CardDescription>
          {mode === "login"
            ? "使用用户名或邮箱登录你的账户"
            : "注册即登录；同一 IP 最多创建 3 个账户"}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs
          value={mode}
          onValueChange={(v) => {
            setMode(v as "login" | "register");
            setError(null);
          }}
        >
          <TabsList className="mb-4 grid w-full grid-cols-2">
            <TabsTrigger value="login" className="gap-1.5">
              <LogIn className="h-4 w-4" /> 登录
            </TabsTrigger>
            <TabsTrigger value="register" className="gap-1.5">
              <UserPlus className="h-4 w-4" /> 注册
            </TabsTrigger>
          </TabsList>

          {/* ---------------- 登录 ---------------- */}
          <TabsContent value="login">
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="login-identifier">用户名或邮箱</Label>
                <Input
                  id="login-identifier"
                  autoComplete="username"
                  placeholder="demo_user 或 you@example.com"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="login-password">密码</Label>
                <Input
                  id="login-password"
                  type="password"
                  autoComplete="current-password"
                  placeholder="请输入密码"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
              {error && (
                <p className="text-sm text-destructive" role="alert">
                  {error}
                </p>
              )}
              <Button type="submit" className="w-full" disabled={submitting}>
                {submitting ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" /> 登录中…
                  </>
                ) : (
                  <>
                    <LogIn className="h-4 w-4" /> 登录
                  </>
                )}
              </Button>
            </form>
          </TabsContent>

          {/* ---------------- 注册 ---------------- */}
          <TabsContent value="register">
            <form onSubmit={handleRegister} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="reg-username">用户名 *</Label>
                <Input
                  id="reg-username"
                  placeholder="以字母开头，3-20 位字母/数字/下划线"
                  value={regUsername}
                  onChange={(e) => setRegUsername(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="reg-email">邮箱 *</Label>
                <Input
                  id="reg-email"
                  type="email"
                  autoComplete="email"
                  placeholder="you@example.com"
                  value={regEmail}
                  onChange={(e) => setRegEmail(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="reg-nickname">
                  昵称 <span className="text-muted-foreground">（选填）</span>
                </Label>
                <Input
                  id="reg-nickname"
                  maxLength={20}
                  placeholder="不超过 20 个字符"
                  value={regNickname}
                  onChange={(e) => setRegNickname(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="reg-password">密码 *</Label>
                <Input
                  id="reg-password"
                  type="password"
                  autoComplete="new-password"
                  placeholder="至少 8 位"
                  value={regPassword}
                  onChange={(e) => setRegPassword(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="reg-confirm">确认密码 *</Label>
                <Input
                  id="reg-confirm"
                  type="password"
                  autoComplete="new-password"
                  placeholder="再次输入密码"
                  value={regConfirm}
                  onChange={(e) => setRegConfirm(e.target.value)}
                />
              </div>

              {/* IP 配额提示 */}
              {ipUsage && (
                <Alert
                  variant={limitReached ? "destructive" : "default"}
                  className="py-3"
                >
                  <Fingerprint className="h-4 w-4" />
                  <AlertTitle>
                    当前 IP（{ipUsage.ip}）已注册 {ipUsage.used}/
                    {ipUsage.limit} 个账户
                  </AlertTitle>
                  <AlertDescription>
                    {limitReached
                      ? "已达注册上限，无法继续注册。系统通过该限制防止批量注册滥用。"
                      : `还可注册 ${ipUsage.remaining} 个账户。达到上限后该 IP 将无法注册新账户。`}
                  </AlertDescription>
                </Alert>
              )}

              {error && (
                <p className="text-sm text-destructive" role="alert">
                  {error}
                </p>
              )}
              <Button
                type="submit"
                className="w-full"
                disabled={submitting || limitReached}
              >
                {submitting ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" /> 注册中…
                  </>
                ) : (
                  <>
                    <UserPlus className="h-4 w-4" /> 立即注册
                  </>
                )}
              </Button>
            </form>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex-col items-center gap-2 border-t bg-muted/40 py-3">
        <p className="text-[11px] leading-relaxed text-muted-foreground">
          本站为在线演示环境：密码经 PBKDF2/scrypt 加盐哈希存储，会话由
          HttpOnly Cookie 维护
        </p>
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="h-7 gap-1 text-xs text-muted-foreground hover:text-destructive"
            >
              <FlaskConical className="h-3.5 w-3.5" />
              演示环境专用：重置全部数据
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>确认重置演示数据？</AlertDialogTitle>
              <AlertDialogDescription>
                将清空所有用户、会话与 IP
                注册记录，且不可恢复。仅用于本演示环境反复测试注册限制等功能。
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>取消</AlertDialogCancel>
              <AlertDialogAction
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                onClick={onReset}
              >
                <Trash2 className="h-4 w-4" /> 确认重置
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </CardFooter>
    </Card>
  );
}

/* ================================================================ */
/*                        控制台仪表盘                                */
/* ================================================================ */

interface DashboardProps {
  me: MeData;
  onLogout: () => void;
  onRefresh: () => void;
}

function Dashboard({ me, onLogout, onRefresh }: DashboardProps) {
  const { toast } = useToast();
  const [sessions, setSessions] = React.useState<SessionInfo[] | null>(null);
  const [nicknameInput, setNicknameInput] = React.useState(me.user.nickname ?? "");
  const [editingNickname, setEditingNickname] = React.useState(false);
  const [savingNickname, setSavingNickname] = React.useState(false);
  const [revoking, setRevoking] = React.useState(false);
  const [loggingOut, setLoggingOut] = React.useState(false);

  const loadSessions = React.useCallback(async () => {
    const res = await api<{ sessions: SessionInfo[] }>("/api/account/sessions");
    if (res.success && res.data) setSessions(res.data.sessions);
  }, []);

  React.useEffect(() => {
    loadSessions();
  }, [loadSessions]);

  const handleSaveNickname = async () => {
    const name = nicknameInput.trim();
    if (name.length > 20) {
      toast({
        title: "昵称过长",
        description: "昵称长度不能超过 20 个字符",
        variant: "destructive",
      });
      return;
    }
    setSavingNickname(true);
    const res = await api("/api/account/profile", {
      method: "PATCH",
      body: JSON.stringify({ nickname: name }),
    });
    setSavingNickname(false);
    if (res.success) {
      setEditingNickname(false);
      toast({ title: "昵称已更新" });
      onRefresh();
    } else {
      toast({
        title: "更新失败",
        description: res.error?.message,
        variant: "destructive",
      });
    }
  };

  const handleRevoke = async (sessionId?: string) => {
    setRevoking(true);
    const res = await api<{ revoked: number }>("/api/account/sessions", {
      method: "DELETE",
      body: JSON.stringify(sessionId ? { sessionId } : {}),
    });
    setRevoking(false);
    if (res.success) {
      toast({
        title: "会话已注销",
        description:
          res.data?.revoked === 1
            ? "已注销所选会话"
            : `已注销其他 ${res.data?.revoked ?? 0} 个会话`,
      });
      loadSessions();
    } else {
      toast({
        title: "操作失败",
        description: res.error?.message,
        variant: "destructive",
      });
    }
  };

  const handleLogout = async () => {
    setLoggingOut(true);
    await api("/api/auth/logout", { method: "POST" });
    setLoggingOut(false);
    toast({ title: "已退出登录" });
    onLogout();
  };

  const displayName = me.user.nickname || me.user.username;
  const usedPercent = (me.ip.used / me.ip.limit) * 100;

  return (
    <motion.section
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35 }}
      className="mx-auto w-full max-w-5xl space-y-6"
    >
      {/* 欢迎栏 */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">
            你好，{displayName}
            <span className="ml-2 align-middle text-sm font-normal text-muted-foreground">
              @{me.user.username}
            </span>
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            这里是你的账户控制台，可以管理资料、查看 IP 注册配额与登录会话。
          </p>
        </div>
        <Button variant="outline" onClick={handleLogout} disabled={loggingOut}>
          {loggingOut ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <LogOut className="h-4 w-4" />
          )}
          退出登录
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* 账户信息卡 */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-base">
              <MonitorSmartphone className="h-4 w-4 text-primary" />
              账户信息
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            <div className="flex items-center justify-between gap-4">
              <span className="text-muted-foreground">昵称</span>
              <span className="flex items-center gap-2 truncate">
                {editingNickname ? (
                  <>
                    <Input
                      value={nicknameInput}
                      maxLength={20}
                      onChange={(e) => setNicknameInput(e.target.value)}
                      className="h-8 w-36"
                      aria-label="修改昵称"
                    />
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-7 w-7 text-emerald-600"
                      onClick={handleSaveNickname}
                      disabled={savingNickname}
                      aria-label="保存昵称"
                    >
                      {savingNickname ? (
                        <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      ) : (
                        <Check className="h-3.5 w-3.5" />
                      )}
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-7 w-7 text-muted-foreground"
                      onClick={() => {
                        setEditingNickname(false);
                        setNicknameInput(me.user.nickname ?? "");
                      }}
                      aria-label="取消修改"
                    >
                      <X className="h-3.5 w-3.5" />
                    </Button>
                  </>
                ) : (
                  <>
                    <span className="font-medium">{me.user.nickname || "未设置"}</span>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-6 w-6 text-muted-foreground"
                      onClick={() => setEditingNickname(true)}
                      aria-label="修改昵称"
                    >
                      <Pencil className="h-3 w-3" />
                    </Button>
                  </>
                )}
              </span>
            </div>
            <Separator />
            <div className="flex items-center justify-between gap-4">
              <span className="text-muted-foreground">邮箱</span>
              <span className="truncate font-medium">{me.user.email}</span>
            </div>
            <Separator />
            <div className="flex items-center justify-between gap-4">
              <span className="text-muted-foreground">注册 IP（脱敏）</span>
              <span className="font-mono">{me.user.registerIp}</span>
            </div>
            <Separator />
            <div className="flex items-center justify-between gap-4">
              <span className="text-muted-foreground">注册时间</span>
              <span>{formatTime(me.user.createdAt)}</span>
            </div>
          </CardContent>
        </Card>

        {/* IP 配额卡 */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-base">
              <ShieldCheck className="h-4 w-4 text-primary" />
              本 IP 注册配额
            </CardTitle>
            <CardDescription>
              出于防滥用考虑，每个 IP 地址最多注册 {me.ip.limit} 个账户
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="mb-2 flex items-center justify-between text-sm">
                <span className="font-mono text-muted-foreground">
                  {me.ip.address}
                </span>
                <span className="font-medium">
                  {me.ip.used} / {me.ip.limit}
                </span>
              </div>
              <Progress
                value={usedPercent}
                aria-label="IP 注册配额使用情况"
                className="h-2.5"
              />
            </div>
            <Alert className="py-3">
              <Database className="h-4 w-4" />
              <AlertTitle>
                {me.ip.used >= me.ip.limit
                  ? "该 IP 已达注册上限"
                  : `还可注册 ${me.ip.limit - me.ip.used} 个账户`}
              </AlertTitle>
              <AlertDescription>
                限制逻辑：服务端每次注册前都会在数据库中统计该 IP
                的历史注册数，达到 {me.ip.limit} 个后拒绝新注册（HTTP 429）。
                生产环境（Cloudflare）直接读取 CF-Connecting-IP 头。
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      </div>

      {/* 会话管理卡 */}
      <Card>
        <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-2">
          <div className="space-y-1">
            <CardTitle className="flex items-center gap-2 text-base">
              <History className="h-4 w-4 text-primary" />
              登录会话管理
            </CardTitle>
            <CardDescription>
              当前账号的全部有效会话（7 天有效期），可随时注销其他设备。
            </CardDescription>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleRevoke()}
            disabled={
              revoking || (sessions?.filter((s) => !s.current).length ?? 0) === 0
            }
          >
            {revoking ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Trash2 className="h-4 w-4" />
            )}
            注销其他会话
          </Button>
        </CardHeader>
        <CardContent>
          {sessions === null ? (
            <p className="py-6 text-center text-sm text-muted-foreground">
              正在加载会话列表…
            </p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>状态</TableHead>
                    <TableHead>登录 IP</TableHead>
                    <TableHead>设备</TableHead>
                    <TableHead>登录时间</TableHead>
                    <TableHead>过期时间</TableHead>
                    <TableHead className="text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sessions.map((s) => (
                    <TableRow key={s.id}>
                      <TableCell>
                        {s.current ? (
                          <Badge>当前设备</Badge>
                        ) : (
                          <Badge variant="outline">其他设备</Badge>
                        )}
                      </TableCell>
                      <TableCell className="font-mono text-xs">{s.ip}</TableCell>
                      <TableCell className="max-w-40 truncate text-xs">
                        {describeUa(s.userAgent)}
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-xs">
                        {formatTime(s.createdAt)}
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-xs">
                        {formatTime(s.expiresAt)}
                      </TableCell>
                      <TableCell className="text-right">
                        {!s.current && (
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-7 text-xs text-destructive hover:text-destructive"
                            onClick={() => handleRevoke(s.id)}
                            disabled={revoking}
                          >
                            注销
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.section>
  );
}

/* ================================================================ */
/*                          首页 Tab                                 */
/* ================================================================ */

export function HomeTab() {
  const [me, setMe] = React.useState<MeData | null>(null);
  const [ipUsage, setIpUsage] = React.useState<IpUsageData | null>(null);
  const [loading, setLoading] = React.useState(true);
  const { toast } = useToast();

  const loadAll = React.useCallback(async () => {
    const [meRes, usageRes] = await Promise.all([
      api<MeData>("/api/auth/me"),
      api<IpUsageData>("/api/ip-usage"),
    ]);
    setMe(meRes.success && meRes.data ? meRes.data : null);
    setIpUsage(usageRes.success && usageRes.data ? usageRes.data : null);
    setLoading(false);
  }, []);

  React.useEffect(() => {
    loadAll();
  }, [loadAll]);

  const handleReset = async () => {
    const res = await api("/api/demo/reset", { method: "DELETE" });
    if (res.success) {
      toast({
        title: "演示数据已重置",
        description: "所有用户、会话与 IP 记录已清空，可重新测试注册限制。",
      });
      loadAll();
    } else {
      toast({
        title: "重置失败",
        description: res.error?.message,
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <div className="flex flex-col items-center gap-3 text-muted-foreground">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-sm">正在加载账户信息…</p>
        </div>
      </div>
    );
  }

  /* ---------- 已登录：控制台 ---------- */
  if (me) {
    return (
      <Dashboard
        me={me}
        onLogout={loadAll}
        onRefresh={loadAll}
      />
    );
  }

  /* ---------- 未登录：Hero + 登录注册 ---------- */
  return (
    <div className="mx-auto grid w-full max-w-6xl items-center gap-10 lg:grid-cols-[1fr_420px] lg:gap-14">
      {/* Hero */}
      <motion.section
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="space-y-7"
      >
        <div className="inline-flex items-center gap-2 rounded-full border border-orange-500/30 bg-orange-500/10 px-3 py-1 text-xs font-medium text-orange-700 dark:text-orange-300">
          <Cloud className="h-3.5 w-3.5" />
          Cloudflare Workers + D1 账户系统参考实现
        </div>

        <h1 className="text-4xl font-bold leading-tight tracking-tight sm:text-5xl">
          轻量、安全、
          <span className="text-primary">可部署到边缘</span>
          的账户系统
        </h1>

        <p className="max-w-xl text-base leading-relaxed text-muted-foreground sm:text-lg">
          集登录注册、会话管理、开放 API
          于一体，内置「同一 IP 最多注册 3 个账户」的防滥用限制。
          右侧即可在线体验，上方标签页提供完整接口文档与 Cloudflare D1
          数据库配置教程。
        </p>

        <div className="grid gap-4 sm:grid-cols-2">
          {FEATURES.map((f) => (
            <div
              key={f.title}
              className="flex gap-3 rounded-xl border border-border/70 bg-card/60 p-4 transition-colors hover:border-orange-500/40"
            >
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-orange-500/10 text-orange-600 dark:text-orange-400">
                <f.icon className="h-5 w-5" />
              </div>
              <div>
                <h3 className="text-sm font-semibold">{f.title}</h3>
                <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                  {f.desc}
                </p>
              </div>
            </div>
          ))}
        </div>

        <p className="text-xs text-muted-foreground">
          * 在线演示基于 Next.js + SQLite 实现同一套接口协议；「部署教程」标签页提供等价的
          Cloudflare Workers + D1 完整代码，可一键复制部署到全球边缘网络。
        </p>
      </motion.section>

      {/* 登录注册卡片 */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45, delay: 0.1 }}
        className="mx-auto w-full max-w-md lg:mx-0"
      >
        <AuthCard ipUsage={ipUsage} onAuthed={loadAll} onReset={handleReset} />
      </motion.div>
    </div>
  );
}
