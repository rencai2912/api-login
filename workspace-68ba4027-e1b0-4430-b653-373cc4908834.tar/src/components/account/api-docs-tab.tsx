"use client";

import * as React from "react";
import {
  BookOpen,
  Lock,
  KeyRound,
  Terminal,
  TriangleAlert,
  Braces,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { CodeBlock } from "@/components/code-block";
import { cn } from "@/lib/utils";

/* ---------------- 接口数据定义 ---------------- */

type Method = "GET" | "POST" | "PATCH" | "DELETE";

interface ParamRow {
  name: string;
  type: string;
  required: boolean;
  desc: string;
}

interface EndpointDoc {
  method: Method;
  path: string;
  title: string;
  auth: "公开" | "需登录";
  desc: string;
  params?: ParamRow[];
  example: string;
  response: string;
  errors?: Array<{ status: number; code: string; desc: string }>;
}

const METHOD_STYLES: Record<Method, string> = {
  GET: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-emerald-500/30",
  POST: "bg-orange-500/15 text-orange-700 dark:text-orange-400 border-orange-500/30",
  PATCH: "bg-amber-500/15 text-amber-700 dark:text-amber-400 border-amber-500/30",
  DELETE: "bg-red-500/15 text-red-700 dark:text-red-400 border-red-500/30",
};

const ENDPOINTS: EndpointDoc[] = [
  {
    method: "POST",
    path: "/api/auth/register",
    title: "注册账户",
    auth: "公开",
    desc: "创建新账户并自动登录（返回 Set-Cookie）。服务端会先校验字段，再检查用户名/邮箱唯一性，最后执行「同一 IP 最多注册 3 个账户」的限制检查。",
    params: [
      { name: "username", type: "string", required: true, desc: "以字母开头，3-20 位，仅支持字母、数字、下划线" },
      { name: "email", type: "string", required: true, desc: "合法邮箱，唯一，存储时统一小写" },
      { name: "password", type: "string", required: true, desc: "至少 8 位，服务端以 scrypt/PBKDF2 加盐哈希存储" },
      { name: "nickname", type: "string", required: false, desc: "昵称，最长 20 字符" },
    ],
    example: `BASE="https://你的域名"   # 演示站可直接省略 BASE 使用相对路径

curl -X POST "$BASE/api/auth/register" \\
  -H "Content-Type: application/json" \\
  -c cookies.txt \\
  -d '{
    "username": "demo_user",
    "email": "demo@example.com",
    "password": "demo12345",
    "nickname": "演示用户"
  }'`,
    response: `// 200 OK —— 同时 Set-Cookie: session_token=...（HttpOnly）
{
  "success": true,
  "data": {
    "user": {
      "id": "cmf8x2a3b4c5",
      "username": "demo_user",
      "email": "demo@example.com",
      "nickname": "演示用户",
      "registerIp": "223.104.**.**",
      "createdAt": "2025-01-01T12:00:00.000Z"
    },
    "ip": { "address": "223.104.3.7", "used": 1, "limit": 3 }
  }
}

// 429 Too Many Requests —— 该 IP 已注册满 3 个账户
{
  "success": false,
  "error": {
    "code": "IP_LIMIT_EXCEEDED",
    "message": "该 IP 地址最多可注册 3 个账户，已达上限",
    "ip": "223.104.3.7",
    "limit": 3,
    "used": 3
  }
}`,
    errors: [
      { status: 400, code: "INVALID_INPUT", desc: "字段格式不正确（用户名/邮箱/密码/昵称）" },
      { status: 409, code: "USERNAME_EXISTS", desc: "用户名已被注册" },
      { status: 409, code: "EMAIL_EXISTS", desc: "邮箱已被注册" },
      { status: 429, code: "IP_LIMIT_EXCEEDED", desc: "★ 该 IP 注册账户数已达上限（3 个）" },
      { status: 429, code: "RATE_LIMITED", desc: "注册请求过于频繁（每 IP 每 10 分钟最多 10 次）" },
    ],
  },
  {
    method: "POST",
    path: "/api/auth/login",
    title: "登录",
    auth: "公开",
    desc: "使用用户名或邮箱 + 密码登录，成功后签发 7 天有效期的 HttpOnly 会话 Cookie。内置防暴力限流：每 IP 每 5 分钟最多 10 次尝试。",
    params: [
      { name: "identifier", type: "string", required: true, desc: "用户名或邮箱（含 @ 时按邮箱匹配）" },
      { name: "password", type: "string", required: true, desc: "账户密码" },
    ],
    example: `curl -X POST "$BASE/api/auth/login" \\
  -H "Content-Type: application/json" \\
  -c cookies.txt \\
  -d '{ "identifier": "demo_user", "password": "demo12345" }'`,
    response: `// 200 OK —— Set-Cookie: session_token=...
{
  "success": true,
  "data": {
    "user": {
      "id": "cmf8x2a3b4c5",
      "username": "demo_user",
      "email": "demo@example.com",
      "nickname": "演示用户",
      "registerIp": "223.104.**.**",
      "createdAt": "2025-01-01T12:00:00.000Z"
    }
  }
}

// 401 —— 账号或密码错误
{ "success": false, "error": { "code": "INVALID_CREDENTIALS", "message": "账号或密码错误" } }`,
    errors: [
      { status: 400, code: "INVALID_INPUT", desc: "缺少账号或密码" },
      { status: 401, code: "INVALID_CREDENTIALS", desc: "账号或密码错误" },
      { status: 429, code: "RATE_LIMITED", desc: "登录尝试过于频繁" },
    ],
  },
  {
    method: "POST",
    path: "/api/auth/logout",
    title: "退出登录",
    auth: "需登录",
    desc: "注销当前会话（删除服务端会话记录）并清除浏览器 Cookie。幂等操作，未登录时调用也返回成功。",
    params: [],
    example: `curl -X POST "$BASE/api/auth/logout" -b cookies.txt`,
    response: `{ "success": true, "data": { "message": "已退出登录" } }`,
    errors: [],
  },
  {
    method: "GET",
    path: "/api/auth/me",
    title: "查询当前用户",
    auth: "需登录",
    desc: "返回当前登录用户信息，以及当前 IP 的注册配额。常用于页面刷新后恢复登录态。",
    params: [],
    example: `curl "$BASE/api/auth/me" -b cookies.txt`,
    response: `// 200 OK
{
  "success": true,
  "data": {
    "user": {
      "id": "cmf8x2a3b4c5",
      "username": "demo_user",
      "email": "demo@example.com",
      "nickname": "演示用户",
      "registerIp": "223.104.**.**",
      "createdAt": "2025-01-01T12:00:00.000Z"
    },
    "ip": { "address": "223.104.3.7", "used": 1, "limit": 3 }
  }
}

// 401 —— 未登录或会话已过期
{ "success": false, "error": { "code": "UNAUTHORIZED", "message": "未登录或会话已过期" } }`,
    errors: [{ status: 401, code: "UNAUTHORIZED", desc: "未登录或会话已过期" }],
  },
  {
    method: "GET",
    path: "/api/ip-usage",
    title: "查询 IP 注册配额",
    auth: "公开",
    desc: "公开接口：返回当前请求 IP 已注册的账户数与上限，注册表单用它在注册前展示配额。",
    params: [],
    example: `curl "$BASE/api/ip-usage"`,
    response: `{
  "success": true,
  "data": { "ip": "223.104.3.7", "used": 1, "limit": 3, "remaining": 2 }
}`,
    errors: [],
  },
  {
    method: "PATCH",
    path: "/api/account/profile",
    title: "更新账户资料",
    auth: "需登录",
    desc: "目前支持修改昵称。传空字符串表示清空昵称。",
    params: [
      { name: "nickname", type: "string", required: false, desc: "新昵称，最长 20 字符；空串表示清空" },
    ],
    example: `curl -X PATCH "$BASE/api/account/profile" \\
  -b cookies.txt \\
  -H "Content-Type: application/json" \\
  -d '{ "nickname": "新昵称" }'`,
    response: `{
  "success": true,
  "data": { "user": { "id": "cmf8x2a3b4c5", "username": "demo_user", "email": "demo@example.com", "nickname": "新昵称", "registerIp": "223.104.**.**", "createdAt": "2025-01-01T12:00:00.000Z" } }
}`,
    errors: [
      { status: 400, code: "INVALID_INPUT", desc: "昵称超过 20 字符" },
      { status: 401, code: "UNAUTHORIZED", desc: "未登录" },
    ],
  },
  {
    method: "GET",
    path: "/api/account/sessions",
    title: "会话列表",
    auth: "需登录",
    desc: "返回当前用户全部有效会话（按登录时间倒序），并用 current 字段标记当前请求所在的会话。登录 IP 已脱敏。",
    params: [],
    example: `curl "$BASE/api/account/sessions" -b cookies.txt`,
    response: `{
  "success": true,
  "data": {
    "sessions": [
      {
        "id": "s_001",
        "ip": "223.104.**.**",
        "userAgent": "Mozilla/5.0 (Windows NT 10.0) ...",
        "createdAt": "2025-01-01T12:00:00.000Z",
        "expiresAt": "2025-01-08T12:00:00.000Z",
        "current": true
      }
    ]
  }
}`,
    errors: [{ status: 401, code: "UNAUTHORIZED", desc: "未登录" }],
  },
  {
    method: "DELETE",
    path: "/api/account/sessions",
    title: "注销会话",
    auth: "需登录",
    desc: "传入 sessionId 则注销指定会话；不传则注销除当前会话外的全部会话（「异地登录一键下线」）。不允许通过此接口注销当前会话，请使用退出登录。",
    params: [
      { name: "sessionId", type: "string", required: false, desc: "要注销的会话 ID；不传表示注销所有其他会话" },
    ],
    example: `# 注销所有其他会话
curl -X DELETE "$BASE/api/account/sessions" -b cookies.txt

# 或注销指定会话
curl -X DELETE "$BASE/api/account/sessions" -b cookies.txt \\
  -H "Content-Type: application/json" \\
  -d '{ "sessionId": "s_002" }'`,
    response: `{ "success": true, "data": { "revoked": 2 } }`,
    errors: [
      { status: 400, code: "INVALID_INPUT", desc: "试图注销当前会话" },
      { status: 401, code: "UNAUTHORIZED", desc: "未登录" },
      { status: 404, code: "NOT_FOUND", desc: "会话不存在" },
    ],
  },
];

/* 全局错误码汇总 */
const ERROR_TABLE: Array<{ code: string; status: string; desc: string }> = [
  { code: "INVALID_INPUT", status: "400", desc: "请求参数缺失或格式不正确" },
  { code: "INVALID_CREDENTIALS", status: "401", desc: "账号或密码错误" },
  { code: "UNAUTHORIZED", status: "401", desc: "未登录或会话已过期" },
  { code: "NOT_FOUND", status: "404", desc: "资源或接口不存在" },
  { code: "USERNAME_EXISTS", status: "409", desc: "用户名已被注册" },
  { code: "EMAIL_EXISTS", status: "409", desc: "邮箱已被注册" },
  { code: "IP_LIMIT_EXCEEDED", status: "429", desc: "该 IP 注册账户数已达上限（3 个）" },
  { code: "RATE_LIMITED", status: "429", desc: "请求过于频繁，请稍后再试" },
  { code: "INTERNAL_ERROR", status: "500", desc: "服务器内部错误" },
];

function MethodBadge({ method }: { method: Method }) {
  return (
    <Badge
      variant="outline"
      className={cn(
        "w-16 justify-center font-mono text-[11px] font-bold",
        METHOD_STYLES[method]
      )}
    >
      {method}
    </Badge>
  );
}

/* ================================================================ */
/*                        API 文档 Tab                               */
/* ================================================================ */

export function ApiDocsTab() {
  return (
    <div className="mx-auto w-full max-w-5xl space-y-8">
      {/* 文档头部 */}
      <header className="space-y-3">
        <div className="flex items-center gap-2">
          <BookOpen className="h-5 w-5 text-primary" />
          <h1 className="text-2xl font-bold tracking-tight">账户系统 API 文档</h1>
        </div>
        <p className="max-w-3xl text-sm leading-relaxed text-muted-foreground">
          本系统对外提供 8 个 REST 接口，覆盖注册、登录、登出、资料、配额与会话管理。
          所有接口返回 <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">application/json</code>，
          并采用统一的响应结构与错误码。当前页面即由这些接口驱动——打开浏览器开发者工具的
          Network 面板即可实时观察调用过程。
        </p>
      </header>

      {/* 基础信息 */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm">
              <Terminal className="h-4 w-4 text-primary" />
              基础地址
            </CardTitle>
          </CardHeader>
          <CardContent className="text-xs leading-relaxed text-muted-foreground">
            <p>
              演示站：<code className="font-mono">/api/*</code>（当前域名）
            </p>
            <p className="mt-1">
              生产部署：<code className="font-mono">https://你的域名/api/*</code>
            </p>
            <p className="mt-1">
              Cloudflare：<code className="font-mono">*.workers.dev/api/*</code>
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm">
              <Braces className="h-4 w-4 text-primary" />
              响应格式
            </CardTitle>
          </CardHeader>
          <CardContent>
            <pre className="overflow-x-auto rounded-lg bg-muted p-3 font-mono text-[11px] leading-relaxed">
{`成功: { "success": true,  "data": { ... } }
失败: { "success": false,
        "error": {
          "code": "错误码",
          "message": "中文描述"
        } }`}
            </pre>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm">
              <Lock className="h-4 w-4 text-primary" />
              认证方式
            </CardTitle>
          </CardHeader>
          <CardContent className="text-xs leading-relaxed text-muted-foreground">
            <p>
              登录/注册成功后服务端通过 <code className="font-mono">Set-Cookie</code>{" "}
              下发 HttpOnly 会话令牌（7 天有效）。
            </p>
            <p className="mt-1.5">
              浏览器同源请求自动携带；curl 使用{" "}
              <code className="font-mono">-c</code> 保存、
              <code className="font-mono">-b</code> 携带；跨域调用需包含{" "}
              <code className="font-mono">credentials</code>。
            </p>
          </CardContent>
        </Card>
      </div>

      {/* 接口列表 */}
      <section className="space-y-4">
        <h2 className="flex items-center gap-2 text-lg font-semibold">
          <KeyRound className="h-5 w-5 text-primary" />
          接口详情
        </h2>
        <Accordion
          type="single"
          collapsible
          defaultValue="POST /api/auth/register"
          className="space-y-3"
        >
          {ENDPOINTS.map((ep) => (
            <AccordionItem
              key={`${ep.method} ${ep.path}`}
              value={`${ep.method} ${ep.path}`}
              className="overflow-hidden rounded-xl border bg-card px-0 data-[state=open]:border-orange-500/40"
            >
              <AccordionTrigger className="hover:no-underline px-5 py-4">
                <div className="flex w-full flex-wrap items-center gap-x-3 gap-y-2 pr-2 text-left">
                  <MethodBadge method={ep.method} />
                  <code className="font-mono text-sm font-semibold text-foreground">
                    {ep.path}
                  </code>
                  <span className="text-sm text-muted-foreground">{ep.title}</span>
                  <Badge
                    variant="secondary"
                    className={
                      ep.auth === "需登录"
                        ? "ml-auto bg-orange-500/10 text-orange-700 dark:text-orange-400"
                        : "ml-auto"
                    }
                  >
                    {ep.auth}
                  </Badge>
                </div>
              </AccordionTrigger>
              <AccordionContent className="space-y-4 px-5 pb-5">
                <p className="text-sm leading-relaxed text-muted-foreground">
                  {ep.desc}
                </p>

                {/* 参数表 */}
                {ep.params && ep.params.length > 0 && (
                  <div className="overflow-x-auto rounded-lg border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>参数</TableHead>
                          <TableHead>类型</TableHead>
                          <TableHead>必填</TableHead>
                          <TableHead>说明</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {ep.params.map((p) => (
                          <TableRow key={p.name}>
                            <TableCell className="font-mono text-xs font-semibold">
                              {p.name}
                            </TableCell>
                            <TableCell className="text-xs text-muted-foreground">
                              {p.type}
                            </TableCell>
                            <TableCell className="text-xs">
                              {p.required ? (
                                <span className="text-red-600 dark:text-red-400">必填</span>
                              ) : (
                                <span className="text-muted-foreground">选填</span>
                              )}
                            </TableCell>
                            <TableCell className="text-xs text-muted-foreground">
                              {p.desc}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}

                {/* 请求示例 */}
                <CodeBlock code={ep.example} language="bash" title="请求示例" />

                {/* 响应示例 */}
                <CodeBlock
                  code={ep.response}
                  language="json"
                  title="响应示例"
                  maxHeightClass="max-h-[22rem]"
                />

                {/* 错误码 */}
                {ep.errors && ep.errors.length > 0 && (
                  <div className="overflow-x-auto rounded-lg border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>HTTP 状态码</TableHead>
                          <TableHead>错误码 code</TableHead>
                          <TableHead>说明</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {ep.errors.map((e) => (
                          <TableRow key={e.code}>
                            <TableCell className="font-mono text-xs font-semibold">
                              {e.status}
                            </TableCell>
                            <TableCell className="font-mono text-xs text-red-600 dark:text-red-400">
                              {e.code}
                            </TableCell>
                            <TableCell className="text-xs text-muted-foreground">
                              {e.desc}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </section>

      {/* 全局错误码 */}
      <section className="space-y-4">
        <h2 className="flex items-center gap-2 text-lg font-semibold">
          <TriangleAlert className="h-5 w-5 text-primary" />
          全局错误码汇总
        </h2>
        <div className="overflow-x-auto rounded-lg border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>错误码</TableHead>
                <TableHead>HTTP 状态码</TableHead>
                <TableHead>含义</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {ERROR_TABLE.map((e) => (
                <TableRow key={e.code}>
                  <TableCell className="font-mono text-xs font-semibold text-red-600 dark:text-red-400">
                    {e.code}
                  </TableCell>
                  <TableCell className="font-mono text-xs">{e.status}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    {e.desc}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </section>

      {/* 前端调用示例 */}
      <section className="space-y-4">
        <h2 className="text-lg font-semibold">在网页中调用（fetch 示例）</h2>
        <CodeBlock
          title="frontend-example.js"
          language="javascript"
          code={`// 1. 登录（同源请求会自动携带 / 接收 Cookie）
async function login(identifier, password) {
  const res = await fetch('/api/auth/login', {
    method: 'POST',
    credentials: 'same-origin',           // 跨域时改为 'include' 并配置 CORS
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ identifier, password }),
  });
  const result = await res.json();
  if (!result.success) throw new Error(result.error.message);
  return result.data.user;
}

// 2. 恢复登录态（页面刷新后调用）
async function fetchMe() {
  const res = await fetch('/api/auth/me', { credentials: 'same-origin' });
  const result = await res.json();
  return result.success ? result.data : null; // null 表示未登录
}

// 3. 处理注册的 IP 限制
async function register(form) {
  const res = await fetch('/api/auth/register', {
    method: 'POST',
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(form),
  });
  const result = await res.json();
  if (result.error?.code === 'IP_LIMIT_EXCEEDED') {
    // 该 IP 已注册满 3 个账户 → 引导用户或提示稍后再试
    alert('当前 IP 注册名额已满：' + result.error.message);
  }
  return result;
}`}
        />
      </section>
    </div>
  );
}
