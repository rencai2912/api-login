"use client";

import * as React from "react";
import { Check, Copy, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { SyntaxHighlighterProps } from "react-syntax-highlighter";
import { oneDark } from "react-syntax-highlighter/dist/esm/styles/prism";
import { cn } from "@/lib/utils";

interface CodeBlockProps {
  /** 代码内容 */
  code: string;
  /** 语言标识，用于语法高亮：bash / javascript / sql / toml / json / text 等 */
  language?: string;
  /** 标题栏展示的文件名或说明 */
  title?: string;
  /** 是否启用语法高亮（默认启用） */
  highlight?: boolean;
  /** 代码区域最大高度（超出滚动），默认 28rem */
  maxHeightClass?: string;
  /** 提供文件名则显示「下载」按钮 */
  downloadAs?: string;
  className?: string;
}

/** 把文本保存为文件并触发下载（仅浏览器端） */
function downloadText(filename: string, text: string) {
  const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export function CodeBlock({
  code,
  language = "text",
  title,
  highlight = true,
  maxHeightClass = "max-h-[28rem]",
  downloadAs,
  className,
}: CodeBlockProps) {
  const [copied, setCopied] = React.useState(false);
  const [Highlighter, setHighlighter] =
    React.useState<React.ComponentType<SyntaxHighlighterProps> | null>(null);

  // 语法高亮器较重，客户端挂载后再动态加载；SSR/加载中渲染纯文本
  React.useEffect(() => {
    let mounted = true;
    import("react-syntax-highlighter")
      .then((m) => {
        if (mounted) setHighlighter(() => m.Prism);
      })
      .catch(() => {});
    return () => {
      mounted = false;
    };
  }, []);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // 剪贴板不可用时退回旧方案
      const ta = document.createElement("textarea");
      ta.value = code;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div
      className={cn(
        "group/code overflow-hidden rounded-xl border border-zinc-800 bg-zinc-950 shadow-sm",
        className
      )}
    >
      {/* 标题栏 */}
      <div className="flex items-center justify-between gap-2 border-b border-zinc-800 bg-zinc-900/80 px-4 py-2">
        <div className="flex min-w-0 items-center gap-2">
          <span
            aria-hidden
            className="flex gap-1.5 [&>span]:h-2.5 [&>span]:w-2.5 [&>span]:rounded-full"
          >
            <span className="bg-red-400/80" />
            <span className="bg-amber-400/80" />
            <span className="bg-emerald-400/80" />
          </span>
          <span className="truncate font-mono text-xs text-zinc-400">
            {title ?? language}
          </span>
        </div>
        <div className="flex items-center gap-1">
          {downloadAs && (
            <Button
              variant="ghost"
              size="sm"
              className="h-7 gap-1.5 px-2 text-xs text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100"
              onClick={() => downloadText(downloadAs, code)}
            >
              <Download className="h-3.5 w-3.5" />
              下载
            </Button>
          )}
          <Button
            variant="ghost"
            size="sm"
            className="h-7 gap-1.5 px-2 text-xs text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100"
            onClick={handleCopy}
            aria-label="复制代码"
          >
            {copied ? (
              <>
                <Check className="h-3.5 w-3.5 text-emerald-400" />
                已复制
              </>
            ) : (
              <>
                <Copy className="h-3.5 w-3.5" />
                复制
              </>
            )}
          </Button>
        </div>
      </div>

      {/* 代码区 */}
      <div className={cn("overflow-auto", maxHeightClass)}>
        {highlight && Highlighter ? (
          <Highlighter
            language={language}
            style={oneDark}
            customStyle={{
              margin: 0,
              padding: "1rem 1.25rem",
              background: "transparent",
              fontSize: "0.8125rem",
              lineHeight: 1.7,
            }}
            wrapLongLines
          >
            {code}
          </Highlighter>
        ) : (
          <pre className="p-4 font-mono text-[0.8125rem] leading-relaxed text-zinc-200">
            <code>{code}</code>
          </pre>
        )}
      </div>
    </div>
  );
}
