import crypto from "crypto";
import type { NextRequest } from "next/server";
import { db } from "@/lib/db";

export const SESSION_COOKIE = "session_token";
export const SESSION_TTL_MS = 7 * 24 * 60 * 60 * 1000; // 会话有效期：7 天
export const MAX_ACCOUNTS_PER_IP = 3; // 每个 IP 最多注册的账户数量

/* ---------------- 密码哈希（scrypt，无需第三方依赖） ---------------- */

export function hashPassword(password: string, salt?: string): string {
  const s = salt ?? crypto.randomBytes(16).toString("hex");
  const hash = crypto.scryptSync(password, s, 32).toString("hex");
  return `scrypt:${s}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [scheme, salt, hash] = stored.split(":");
  if (scheme !== "scrypt" || !salt || !hash) return false;
  const computed = crypto.scryptSync(password, salt, 32).toString("hex");
  try {
    return crypto.timingSafeEqual(
      Buffer.from(computed, "hex"),
      Buffer.from(hash, "hex")
    );
  } catch {
    return false;
  }
}

/* ---------------- 客户端 IP 检测 ---------------- */

/**
 * 获取客户端真实 IP。
 * 网关/反向代理场景下解析 x-forwarded-for 的第一个地址；
 * 在 Cloudflare Workers 生产环境中应使用 CF-Connecting-IP 头。
 */
export function getClientIp(req: NextRequest): string {
  const xff = req.headers.get("x-forwarded-for");
  if (xff) {
    const first = xff.split(",")[0]?.trim();
    if (first) return first;
  }
  return req.headers.get("x-real-ip") ?? req.headers.get("cf-connecting-ip") ?? "127.0.0.1";
}

/** 对 IP 做脱敏展示，如 223.104.**.** / 2408:8456::**** */
export function maskIp(ip: string): string {
  if (ip.includes(":")) {
    const parts = ip.split(":").filter(Boolean);
    return parts.length >= 2 ? `${parts.slice(0, 2).join(":")}::****` : ip;
  }
  const parts = ip.split(".");
  if (parts.length === 4) return `${parts[0]}.${parts[1]}.**.**`;
  return ip;
}

/* ---------------- 会话管理 ---------------- */

export function generateSessionToken(): string {
  return crypto.randomBytes(32).toString("hex");
}

export async function createSession(
  userId: string,
  ip: string,
  userAgent: string
) {
  const token = generateSessionToken();
  const expiresAt = new Date(Date.now() + SESSION_TTL_MS);
  await db.session.create({
    data: { token, userId, ip, userAgent, expiresAt },
  });
  return { token, expiresAt };
}

/** 从请求 Cookie 中解析当前会话（含用户信息），无效或过期返回 null */
export async function getSession(req: NextRequest) {
  const token = req.cookies.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const session = await db.session.findUnique({
    where: { token },
    include: { user: true },
  });
  if (!session) return null;
  if (session.expiresAt < new Date()) {
    await db.session.delete({ where: { id: session.id } }).catch(() => {});
    return null;
  }
  return session;
}

/** 惰性清理：删除所有已过期会话 */
export async function cleanExpiredSessions() {
  await db.session
    .deleteMany({ where: { expiresAt: { lt: new Date() } } })
    .catch(() => {});
}

/** 对外输出的用户字段（隐藏密码哈希，并对注册 IP 脱敏） */
export function publicUser(u: {
  id: string;
  username: string;
  email: string;
  nickname: string | null;
  registerIp: string;
  createdAt: Date;
}) {
  return {
    id: u.id,
    username: u.username,
    email: u.email,
    nickname: u.nickname,
    registerIp: maskIp(u.registerIp),
    createdAt: u.createdAt,
  };
}

/** 查询某个 IP 已注册的账户数 */
export async function countIpRegistrations(ip: string): Promise<number> {
  return db.ipRegistration.count({ where: { ip } });
}

/* ---------------- 简单内存限流（防止暴力登录） ---------------- */

type Bucket = { count: number; resetAt: number };
const buckets = new Map<string, Bucket>();

export function rateLimit(
  key: string,
  max: number,
  windowMs: number
): { allowed: boolean; retryAfterSec: number } {
  const now = Date.now();
  const bucket = buckets.get(key);
  if (!bucket || bucket.resetAt < now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return { allowed: true, retryAfterSec: 0 };
  }
  if (bucket.count >= max) {
    return {
      allowed: false,
      retryAfterSec: Math.ceil((bucket.resetAt - now) / 1000),
    };
  }
  bucket.count += 1;
  return { allowed: true, retryAfterSec: 0 };
}
