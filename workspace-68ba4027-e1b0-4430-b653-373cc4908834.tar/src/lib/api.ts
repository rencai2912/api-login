import { NextResponse } from "next/server";

/** 统一成功响应：{ success: true, data } */
export function ok<T>(data: T, init?: ResponseInit) {
  return NextResponse.json({ success: true, data }, init);
}

/** 统一失败响应：{ success: false, error: { code, message } } */
export function fail(
  status: number,
  code: string,
  message: string,
  extra?: Record<string, unknown>
) {
  return NextResponse.json(
    { success: false, error: { code, message, ...extra } },
    { status }
  );
}
